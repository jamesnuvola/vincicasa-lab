#!/usr/bin/env python3
"""Q141-B7: strict-prior anticipation across Q90 operator/size formula families."""
from __future__ import annotations
import argparse, csv, gzip, hashlib, io, json, math, os, zipfile
from pathlib import Path
from datetime import date
import numpy as np

EXPECTED_ZIP_SHA = "12df057170bc87e5ea36406d52b4ebf3d749e03d95a36a656e07334f1d049077"
EXPECTED_ARCHIVE_BLOB = "5d2efd70684e918b27d8f06386d545647898336d"
EXPECTED_MATRIX_SHA = "681152ddfaa0217889f0a1623f0ce1dc9691ffabdd4901869cb736b58185ec49"
EXPECTED_CATALOG_SHA = "a61f77ede7136d4eb88a57932488590741fd0b84ace8307d5dd90c192d520586"
EXPECTED_LEDGER_SHA = "553ea2519f109cf0913f86a43210481f7e9ac346128f18698d425036d4e1c120"
EXPECTED_MEMBERS = {
"adaptive_novelty_checkpoint_2026-11-01.json":"5782d08ece77898787b007f0d6da260537aafe8496f1e94c335d050a88ef845c",
"adaptive_novelty_checkpoint_2026-11-02.json":"2791748a71d92ce3eaf1dc5e98e6e4de4c7e19dd2d694719e11bc759fc2ecba1",
"adaptive_novelty_checkpoint_2026-11-07.json":"99b4044d10a1a4a81bb82e10cc48c6b58a1104610cb277a103a7ddbfdf37df9a",
"adaptive_novelty_feature_catalog.json":"0761324a35faade7e5dc9a053d19146f21d349ba9e8237b334691c6b1e5517a5",
"adaptive_novelty_feature_matrix.npz":EXPECTED_MATRIX_SHA,
"adaptive_novelty_formula_metrics_manifest.json":"2ae099e714d1eae46688e4ade37b4eda1a8303cee729e5879faff5b1fff6d6cb",
"adaptive_novelty_regime_drift.json":"9ee2f4f295f3e0f4f8e7b0371eb14430d9f9b776524cd6eee389d60b5e8cd830",
"adaptive_novelty_rule_anticipation_metrics.csv":"ff4b0ad4263a480d7ce02bc84040e686871b10abdc6552e4b26ccebf97097785",
"adaptive_novelty_split_metrics.csv":"4230582d3062066d28c2a6d35da7cc6ca8bee657e9d6bcdee03a2b205ecbf352",
"adaptive_novelty_target_ledger.csv":"4e72f13912a69ae4182a9bda4a8de62e59fd4d67056bc42151d96f679ee1f569",
"q90_checkpoint_2026-11-07.json":"3da9755582727ebe96747f7d3b7a9cdb27f1afea70ac02066fb5de54fd7b1ee8",
"q90_feature_selection.json":"0e752f901f1d5f8f7c4b7d8436f38e3939ee2ab7018dc4229a0e1fddd3c08ed9",
"q90_formula_catalog.csv":EXPECTED_CATALOG_SHA,
"q90_formula_family_split_summary.json":"aff80ea4ed4204a55237ea626e2ee54d9816d648e879e9cef7bcc8ee27106f70",
"q90_formula_metrics_manifest.json":"30ea0587f00fab25b06358a32aa01e6dd72b82ffa673dc99981c522cd1a95272",
"q90_split_metrics.csv":"3192a5ab2a64e8526321b6b5c322320dfc5636e337eadde573b5e27b0461ec2a",
"q90_target_ledger.csv":EXPECTED_LEDGER_SHA,
}
FAMILY_NAMES = ["linear_mean_L4","linear_mean_L5","linear_mean_L6","linear_mean_L7","linear_mean_L8","pairwise_interaction_I4","conditional_gate_G4"]
FAMILY_INDEX = {name:i for i,name in enumerate(FAMILY_NAMES)}
SAMPLE_PER_FAMILY = 100
WINDOW = 100
BLOCK = 20
REPS = 20000
SEED = 14120261112


def sha256(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def verify_zip(path: Path) -> zipfile.ZipFile:
    raw = path.read_bytes()
    if sha256(raw) != EXPECTED_ZIP_SHA:
        raise ValueError("Q141_B7_BLOCKED: Q90 artifact ZIP SHA-256 mismatch")
    z = zipfile.ZipFile(io.BytesIO(raw))
    names = set(z.namelist())
    if names != set(EXPECTED_MEMBERS):
        raise ValueError("Q141_B7_BLOCKED: artifact member set mismatch")
    for name, expected in EXPECTED_MEMBERS.items():
        actual = sha256(z.read(name))
        if actual != expected:
            raise ValueError(f"Q141_B7_BLOCKED: member SHA mismatch: {name}")
    return z


def read_json(z, name):
    return json.loads(z.read(name).decode("utf-8"))


def sample_catalog(z, feature_names, selected_names):
    feature_index = {name:i for i,name in enumerate(feature_names)}
    selected_indices = np.array([feature_index[n] for n in selected_names], dtype=np.int64)
    selected_local = {int(g):i for i,g in enumerate(selected_indices)}
    candidates = {name:[] for name in FAMILY_NAMES}
    reader = csv.DictReader(io.StringIO(z.read("q90_formula_catalog.csv").decode("utf-8")))
    seen = set(); counts = {name:0 for name in FAMILY_NAMES}
    for row in reader:
        fid = row["formula_id"]
        if fid in seen: raise ValueError("Q141_B7_BLOCKED: duplicate formula ID")
        seen.add(fid)
        typ = row["formula_type"]; size = int(row["formula_size"])
        if typ == "linear_mean": fam = f"linear_mean_L{size}"
        elif typ == "pairwise_interaction": fam = "pairwise_interaction_I4"
        elif typ == "conditional_gate": fam = "conditional_gate_G4"
        else: raise ValueError("Q141_B7_BLOCKED: unknown formula type")
        counts[fam] += 1
        h = hashlib.sha256(("Q141-B7|"+fid).encode()).hexdigest()
        if len(candidates[fam]) < SAMPLE_PER_FAMILY or h < candidates[fam][-1][0]:
            item = (h,row)
            candidates[fam].append(item)
            candidates[fam].sort(key=lambda x:x[0])
            if len(candidates[fam]) > SAMPLE_PER_FAMILY: candidates[fam].pop()
    if len(seen) != 330429: raise ValueError(f"Q141_B7_BLOCKED: catalog rows {len(seen)} != 330429")
    if counts != {"linear_mean_L4":4845,"linear_mean_L5":15504,"linear_mean_L6":38760,"linear_mean_L7":77520,"linear_mean_L8":125970,"pairwise_interaction_I4":29070,"conditional_gate_G4":38760}:
        raise ValueError("Q141_B7_BLOCKED: formula family counts differ from Q90 manifest")
    sample=[]
    for fam in FAMILY_NAMES:
        if len(candidates[fam]) != SAMPLE_PER_FAMILY: raise ValueError("Q141_B7_BLOCKED: incomplete family sample")
        for _,row in candidates[fam]:
            ids=[int(x) for x in row["feature_indices"].split(";")]
            names=row["features"].split("+")
            if len(ids) != len(names) or any(feature_names[i] != n for i,n in zip(ids,names)):
                raise ValueError("Q141_B7_BLOCKED: feature lineage mismatch")
            if any(i not in selected_local for i in ids):
                raise ValueError("Q141_B7_BLOCKED: formula references a feature outside frozen 20-feature subset")
            local=tuple(sorted(selected_local[i] for i in ids))
            x={"formula_id":row["formula_id"],"family":fam,"type":row["formula_type"],"size":int(row["formula_size"]),"global_ids":ids,"local_ids":local}
            if x["type"]=="pairwise_interaction":
                a,b=row["interaction_pair"].split("*")
                x["pair_local"]=(selected_local[feature_index[a]],selected_local[feature_index[b]])
                x["weight"]=float(row["weight"])
                if x["weight"]!=0.25: raise ValueError("Q141_B7_BLOCKED: unexpected interaction weight")
            elif x["type"]=="conditional_gate":
                x["gate_local"]=selected_local[feature_index[row["gate_feature"]]]
                x["threshold"]=float(row["gate_threshold"])
                x["weight"]=float(row["weight"])
                if x["weight"]!=0.25 or x["threshold"] not in (0.5,1.0): raise ValueError("Q141_B7_BLOCKED: unexpected gate parameters")
            sample.append(x)
    ids=[x["formula_id"] for x in sample]
    if len(ids)!=len(set(ids)): raise ValueError("Q141_B7_BLOCKED: sampled formula IDs not unique")
    return sample, selected_indices, counts


def build_formula_arrays(sample, selected_indices):
    n=len(sample); W=np.zeros((20,n),dtype=np.float64)
    families=[]; inter_cols=[]; inter_pairs=[]; gate_cols=[]; gate_features=[]; gate_thresholds=[]
    pair_list=sorted({tuple(sorted(x["pair_local"])) for x in sample if x["type"]=="pairwise_interaction"})
    pairmap={p:i for i,p in enumerate(pair_list)}
    for j,x in enumerate(sample):
        for p in x["local_ids"]: W[p,j]=1.0/x["size"]
        families.append(FAMILY_INDEX[x["family"]])
        if x["type"]=="pairwise_interaction":
            inter_cols.append(j); inter_pairs.append(pairmap[tuple(sorted(x["pair_local"]))])
        elif x["type"]=="conditional_gate":
            gate_cols.append(j); gate_features.append(x["gate_local"]); gate_thresholds.append(x["threshold"])
    return W,np.array(families),np.array(inter_cols),np.array(inter_pairs),np.array(gate_cols),np.array(gate_features),np.array(gate_thresholds),pair_list


def score_one_target(X, W, sample, inter_cols, inter_pairs, gate_cols, gate_features, gate_thresholds, pair_list):
    base=np.round(X@W,12)
    scores=base.copy()
    if len(inter_cols):
        pairz=np.empty((40,len(pair_list)),dtype=np.float64)
        for j,(a,b) in enumerate(pair_list):
            prod=X[:,a]*X[:,b]; sd=float(prod.std())
            if sd<1e-12: sd=1.0
            pairz[:,j]=(prod-prod.mean())/sd
        scores[:,inter_cols]=np.round(base[:,inter_cols]+0.25*pairz[:,inter_pairs],12)
    if len(gate_cols):
        gate_bonus=(X[:,gate_features]>=gate_thresholds[None,:]).astype(np.float64)
        scores[:,gate_cols]=np.round(base[:,gate_cols]+0.25*gate_bonus,12)
    return scores

def family_outcomes_for_target(scores, actual, families):
    cand=np.arange(40)[:,None]
    ranks=np.empty((5,scores.shape[1]),dtype=np.int16)
    for j,a in enumerate(actual):
        v=scores[int(a),:][None,:]
        ranks[j]=1+(scores>v).sum(axis=0)+((scores==v)&(cand<int(a))).sum(axis=0)
    hit5=(ranks<=5).sum(axis=0)/5.0
    return np.array([float(hit5[families==g].mean()) for g in range(len(FAMILY_NAMES))])


def select_families(outcomes):
    n=len(outcomes); selected=[]
    for t in range(n):
        if t<WINDOW: selected.append(-1)
        else:
            m=outcomes[t-WINDOW:t].mean(axis=0)
            selected.append(int(np.argmax(m)))
    return np.array(selected,dtype=np.int16)


def block_sums(d, block=BLOCK):
    full=len(d)//block; rem=len(d)%block
    full_sums=np.array([d[i*block:(i+1)*block].sum() for i in range(full)],dtype=np.float64)
    partial_sums=np.array([d[i:i+rem].sum() for i in range(len(d)-rem+1)],dtype=np.float64) if rem else np.array([0.0])
    return full_sums,partial_sums,rem


def block_signflip_p(d, rng):
    full_sums,partial_sums,rem=block_sums(d)
    blocks=len(full_sums)+(1 if rem else 0)
    obs=float(d.mean())
    signs=rng.choice(np.array([-1.0,1.0]),size=(REPS,blocks))
    total=signs[:,:len(full_sums)]@full_sums
    if rem: total+=signs[:,-1]*partial_sums[0]
    null=total/len(d)
    return float((1+np.sum(null>=obs))/(REPS+1)),int(blocks)


def circular_mbb_ci(d, rng):
    n=len(d); full=n//BLOCK; rem=n%BLOCK
    ext=np.concatenate([d,d[:BLOCK]])
    cs=np.concatenate([[0.0],np.cumsum(ext)])
    full_sums=cs[BLOCK:BLOCK+n]-cs[:n]
    if rem:
        csr=np.concatenate([[0.0],np.cumsum(np.concatenate([d,d[:rem]]))])
        partial_sums=csr[rem:rem+n]-csr[:n]
    starts=rng.integers(0,n,size=(REPS,full))
    totals=full_sums[starts].sum(axis=1)
    if rem:
        last=rng.integers(0,n,size=REPS)
        totals+=partial_sums[last]
    vals=totals/n
    return [float(np.quantile(vals,0.025)),float(np.quantile(vals,0.975))]

def holm(pvals):
    p=np.asarray(pvals,dtype=float); order=np.argsort(p,kind="mergesort"); out=np.empty_like(p); running=0.0
    for rank,idx in enumerate(order):
        running=max(running,min(1.0,(len(p)-rank)*p[idx])); out[idx]=running
    return out.tolist()


def run_selector(outcomes, split_names):
    sel=select_families(outcomes); n=len(outcomes)
    equal=outcomes.mean(axis=1)
    rolling=np.array([equal[t] if sel[t]<0 else outcomes[t,sel[t]] for t in range(n)])
    discovery=np.array([s=="discovery" for s in split_names])
    means=outcomes[discovery].mean(axis=0)
    static_idx=int(np.argmax(means))
    static=outcomes[:,static_idx]
    return sel,rolling,equal,static,static_idx,means


def main(artifact_path:Path,outdir:Path):
    z=verify_zip(artifact_path)
    manifest=read_json(z,"q90_formula_metrics_manifest.json")
    feature_catalog=read_json(z,"adaptive_novelty_feature_catalog.json")
    selection=read_json(z,"q90_feature_selection.json")
    if manifest["archive"]["blob_sha"]!=EXPECTED_ARCHIVE_BLOB: raise ValueError("Q141_B7_BLOCKED: archive blob mismatch")
    if manifest["formula_grammar"]["formula_count"]!=330429: raise ValueError("Q141_B7_BLOCKED: formula count mismatch")
    if manifest["q89_feature_matrix"]["sha256"]!=EXPECTED_MATRIX_SHA: raise ValueError("Q141_B7_BLOCKED: matrix manifest hash mismatch")
    with np.load(io.BytesIO(z.read("adaptive_novelty_feature_matrix.npz")),allow_pickle=False) as npz:
        X=npz["feature_matrix"]
        dates=npz["target_dates"].astype(str)
        cutoffs=npz["cutoff_dates"].astype(str)
        actuals=npz["actual_quintets"].astype(np.int16)
        feature_names=npz["feature_names"].astype(str).tolist()
        matrix_archive=str(npz["archive_blob_sha"].item())
    if X.shape!=(3351,40,59) or X.dtype!=np.float32 or not np.isfinite(X).all(): raise ValueError("Q141_B7_BLOCKED: feature matrix shape/dtype/finite check failed")
    if matrix_archive!=EXPECTED_ARCHIVE_BLOB: raise ValueError("Q141_B7_BLOCKED: matrix archive provenance mismatch")
    if len(selection["selected_features"])!=20: raise ValueError("Q141_B7_BLOCKED: selected feature count mismatch")
    selected_names=[x["feature"] for x in selection["selected_features"]]
    if selected_names!=manifest["selected_features"]: raise ValueError("Q141_B7_BLOCKED: feature selection order mismatch")
    sample,selected_indices,counts=sample_catalog(z,feature_names,selected_names)
    # Cross-check target ledger dates, cutoffs and outcomes against the NPZ arrays.
    ledger=list(csv.DictReader(io.StringIO(z.read("q90_target_ledger.csv").decode("utf-8"))))
    if len(ledger)!=3351: raise ValueError("Q141_B7_BLOCKED: target ledger row count mismatch")
    splits=[]
    for i,row in enumerate(ledger):
        actual=[int(x) for x in row["actual_quintet"].split()]
        if row["target_date"]!=dates[i] or row["cutoff_date"]!=cutoffs[i] or actual!=actuals[i].tolist():
            raise ValueError(f"Q141_B7_BLOCKED: target ledger/NPZ mismatch at row {i}")
        if not row["cutoff_date"]<row["target_date"]: raise ValueError("Q141_B7_BLOCKED: non-prior cutoff")
        splits.append(row["split"])
    expected={"discovery":2011,"validation":670,"blind_oos":670}
    if {s:splits.count(s) for s in expected}!=expected: raise ValueError("Q141_B7_BLOCKED: split counts mismatch")
    W,families,inter_cols,inter_pairs,gate_cols,gate_features,gate_thresholds,pair_list=build_formula_arrays(sample,selected_indices)
    outcomes=np.empty((len(X),len(FAMILY_NAMES)),dtype=np.float64)
    for t in range(len(X)):
        Xsel=X[t][:,selected_indices].astype(np.float64,copy=False)
        scores=score_one_target(Xsel,W,sample,inter_cols,inter_pairs,gate_cols,gate_features,gate_thresholds,pair_list)
        outcomes[t]=family_outcomes_for_target(scores,actuals[t]-1,families)
    sel,rolling,equal,static,static_idx,static_means=run_selector(outcomes,splits)
    # Verify target-t choice is invariant to target-t and future family outcomes.
    altered=outcomes.copy(); altered[150:,:]=np.flip(altered[150:,:],axis=1)
    sel_alt=select_families(altered)
    if not np.array_equal(sel[:151],sel_alt[:151]): raise ValueError("Q141_B7_BLOCKED: selector depends on current/future outcomes")
    rows=[]
    for t in range(len(X)):
        rows.append({"target_index":t,"target_date":dates[t],"cutoff_date":cutoffs[t],"prior_draws":t+50,"split":splits[t],"actual_quintet":" ".join(map(str,actuals[t].tolist())),"selected_family":FAMILY_NAMES[sel[t]] if sel[t]>=0 else "EQUAL_WARMUP","rolling_top5_share":rolling[t],"equal_family_top5_share":equal[t],"static_discovery_family":FAMILY_NAMES[static_idx],"static_family_top5_share":static[t],**{FAMILY_NAMES[g]:outcomes[t,g] for g in range(len(FAMILY_NAMES))}})
    outdir.mkdir(parents=True,exist_ok=True)
    ledger_path=outdir/"q141_q90_family_persistence_target_ledger_2026-11-12.csv"
    with ledger_path.open("w",newline="",encoding="utf-8") as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0])); w.writeheader(); w.writerows(rows)
    tests=[]; rng=np.random.default_rng(SEED)
    for split in ("discovery","validation","blind_oos"):
        idx=np.array([s==split for s in splits])
        for comparator,series in (("rolling_vs_equal",rolling-equal),("discovery_static_vs_equal",static-equal)):
            d=series[idx]
            p,blocks=block_signflip_p(d,rng); ci=circular_mbb_ci(d,rng)
            tests.append({"id":f"{split}_{comparator}","split":split,"comparison":comparator,"targets":int(idx.sum()),"mean_effect":float(d.mean()),"ci95_circular_mbb":ci,"p_raw_one_sided":p,"blocks":blocks,"block_length":BLOCK})
    adj=holm([x["p_raw_one_sided"] for x in tests])
    for x,p in zip(tests,adj): x["p_holm_all_6"]=p
    blind=next(x for x in tests if x["id"]=="blind_oos_rolling_vs_equal")
    decision="NO_FAMILY_PERSISTENCE_LIFT_DEMONSTRATED"
    if blind["mean_effect"]>=0.005 and blind["ci95_circular_mbb"][0]>0 and blind["p_holm_all_6"]<0.05:
        decision="PREREGISTERED_FAMILY_PERSISTENCE_CRITERIA_MET_REQUIRES_INDEPENDENT_REVIEW"
    split_summary={}
    for split in expected:
        idx=np.array([s==split for s in splits])
        split_summary[split]={"targets":int(idx.sum()),"rolling_top5_share":float(rolling[idx].mean()),"equal_family_top5_share":float(equal[idx].mean()),"static_family_top5_share":float(static[idx].mean()),"uniform_reference":0.125,"selected_family_counts":{FAMILY_NAMES[g]:int(np.sum(sel[idx]==g)) for g in range(len(FAMILY_NAMES))},"mean_family_top5_share":{FAMILY_NAMES[g]:float(outcomes[idx,g].mean()) for g in range(len(FAMILY_NAMES))}}
    report={"schema_version":"1.0","task_id":"Q141-B7","status":"COMPUTED","decision":decision,"hypothesis":"Q90 operator/size family success over the prior 100 targets predicts next-target family-average Top-5 hit share.","source":{"artifact_id":13627507532,"artifact_run_id":42504717670,"artifact_sha256":EXPECTED_ZIP_SHA,"archive_blob_sha1":EXPECTED_ARCHIVE_BLOB,"draw_count":3401,"cutoff":"2026-11-07","feature_matrix_shape":list(X.shape),"feature_matrix_sha256":EXPECTED_MATRIX_SHA,"q141_archive_eligible_draws":3404,"q141_archive_cutoff":"2026-11-10","contest_315_excluded":True},"formula_universe":{"full_catalog_count":330429,"family_counts":counts,"sample_per_family":SAMPLE_PER_FAMILY,"sample_count":len(sample),"sample_method":"lowest SHA-256('Q141-B7|'+formula_id) within each family","families":FAMILY_NAMES,"sample_formula_ids_sha256":sha256("\n".join(x["formula_id"] for x in sample).encode())},"walkforward":{"targets":len(X),"split_counts":expected,"strict_prior":True,"window":WINDOW,"update_order":"score target before updating family history","warmup_targets":WINDOW,"static_family_selected_on_discovery":FAMILY_NAMES[static_idx],"static_family_discovery_means":{FAMILY_NAMES[g]:float(static_means[g]) for g in range(len(FAMILY_NAMES))},"split_summary":split_summary},"statistical_inference":{"block_length":BLOCK,"sign_flip_replicates":REPS,"circular_mbb_replicates":REPS,"seed":SEED,"registered_tests":6,"multiplicity":"Holm-Bonferroni across six registered split/comparator tests","tests":tests,"primary_blind_test":blind,"minimum_practical_effect":0.005},"acceptance":{"artifact_zip_and_17_member_hashes_verified":True,"matrix_shape_dtype_finite_and_archive_hash_verified":True,"feature_selection_order_verified":True,"catalog_formula_count_and_family_counts_verified":True,"sample_formula_ids_unique_and_deterministic":True,"target_dates_cutoffs_actuals_reconciled_to_ledger":True,"cutoff_strictly_before_target":True,"selector_current_future_outcome_invariance_test":True,"selector_updates_after_target_scoring":True,"all_six_registered_tests_holm_adjusted":True},"limitations":["700 of 330429 Q90 formulas are sampled; the full catalog is not evaluated target-by-target.","Q90 selected 20 features on Discovery; Discovery results are descriptive/in-sample.","Historical Blind OOS is exposed SONAR research history, not virgin prospective evidence.","Family-average Top-5 hit share is a meta-research diagnostic, not a deployable number ranking or quintet forecast.","Holm controls six Q141-B7 comparisons, not the full Q00-Q141 research history."],"next_action":"Import Q90 artifact into durable hash-pinned repository storage and extend typed AST registry; do not tune this selector from Blind OOS.","governance":{"research_only":True,"no_merge":True,"no_engine_promotion":True,"no_shadow_insertion":True,"no_canonical_archive_mutation":True,"protected_prs":[6,7,8]}}
    report_path=outdir/"q141_q90_family_persistence_report_2026-11-12.json"
    report_path.write_text(json.dumps(report,indent=2)+"\n",encoding="utf-8")
    manifest={"schema_version":"1.0","task_id":"Q141-B7","status":"OUTPUTS_COMPUTED","artifact_sha256":EXPECTED_ZIP_SHA,"formula_sample_count":len(sample),"target_count":len(X),"ledger_rows":len(rows),"report_sha256":sha256(report_path.read_bytes()),"ledger_sha256":sha256(ledger_path.read_bytes()),"report_path":report_path.name,"ledger_path":ledger_path.name}
    manifest_path=outdir/"q141_q90_family_persistence_manifest_2026-11-12.json"
    manifest_path.write_text(json.dumps(manifest,indent=2)+"\n",encoding="utf-8")
    checkpoint={"schema_version":"1.0","task_id":"Q141-B7","status":"COMPUTED","report_sha256":manifest["report_sha256"],"ledger_sha256":manifest["ledger_sha256"],"next_action":report["next_action"]}
    (outdir/"q141_q90_family_persistence_checkpoint_2026-11-12.json").write_text(json.dumps(checkpoint,indent=2)+"\n",encoding="utf-8")
    print(json.dumps({"decision":decision,"blind":blind,"split_summary":split_summary,"tests":tests,"manifest":manifest},indent=2))

if __name__=="__main__":
    ap=argparse.ArgumentParser(); ap.add_argument("--artifact-path",type=Path,required=True); ap.add_argument("--output-dir",type=Path,required=True); a=ap.parse_args(); main(a.artifact_path,a.output_dir)
