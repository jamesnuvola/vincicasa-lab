#!/usr/bin/env python3
"""Q141-A6: deterministic 59-feature covering-sample walk-forward audit.

The experiment compares a fixed, family-balanced sample over all 59 Q89 features
with a size-matched sample over Q90's Discovery-selected 20 features. It does not
select formulas using target outcomes and never treats historical Blind OOS as
virgin prospective evidence.
"""
from __future__ import annotations
import argparse, csv, hashlib, itertools, json, math, zipfile
from collections import Counter, defaultdict
from pathlib import Path
import numpy as np

TASK = "Q141-A6"
SEED = 14120261113
N_QUARTETS = 350
LINEAR_PER_SIZE = 75
SIZES = (5, 6, 7, 8)
BLOCK_LENGTH = 20
BOOTSTRAP_REPLICATES = 20000
PRACTICAL_THRESHOLD = 0.005
UNIFORM_TOP5 = 0.125
EXPECTED = {
 "zip_sha256":"12df057170bc87e5ea36406d52b4ebf3d749e03d95a36a656e07334f1d049077",
 "matrix_sha256":"681152ddfaa0217889f0a1623f0ce1dc9691ffabdd4901869cb736b58185ec49",
 "catalog_sha256":"a61f77ede7136d4eb88a57932488590741fd0b84ace8307d5dd90c192d520586",
 "selection_sha256":"0e752f901f1d5f8f7c4b7d8436f38e3939ee2ab7018dc4229a0e1fddd3c08ed9",
 "ledger_sha256":"553ea2519f109cf0913f86a43210481f7e9ac346128f18698d425036d4e1c120",
 "split_metrics_sha256":"3192a5ab2a64e8526321b6b5c322320dfc5636e337eadde573b5e27b0461ec2a",
 "feature_catalog_sha256":"0761324a35faade7e5dc9a053d19146f21d349ba9e8237b334691c6b1e5517a5",
 "q90_archive_blob":"5d2efd70684e918b27d8f06386d545647898336d",
 "q141_archive_blob":"fcb453ed06c8002314f826dbac79d6935f9ac103",
 "draws":3401,"targets":3351,"features":59,"candidates":40,
 "split_counts":{"discovery":2011,"validation":670,"blind_oos":670},
}
MEMBERS = {
"adaptive_novelty_checkpoint_2026-11-01.json":(1727,"5782d08ece77898787b007f0d6da260537aafe8496f1e94c335d050a88ef845c"),
"adaptive_novelty_checkpoint_2026-11-02.json":(3094,"2791748a71d92ce3eaf1dc5e98e6e4de4c7e19dd2d694719e11bc759fc2ecba1"),
"adaptive_novelty_checkpoint_2026-11-07.json":(575,"99b4044d10a1a4a81bb82e10cc48c6b58a1104610cb277a103a7ddbfdf37df9a"),
"adaptive_novelty_feature_catalog.json":(8215,"0761324a35faade7e5dc9a053d19146f21d349ba9e8237b334691c6b1e5517a5"),
"adaptive_novelty_feature_matrix.npz":(21345478,"681152ddfaa0217889f0a1623f0ce1dc9691ffabdd4901869cb736b58185ec49"),
"adaptive_novelty_formula_metrics_manifest.json":(6944,"2ae099e714d1eae46688e4ade37b4eda1a8303cee729e5879faff5b1fff6d6cb"),
"adaptive_novelty_regime_drift.json":(23358,"9ee2f4f295f3e0f4f8e7b0371eb14430d9f9b776524cd6eee389d60b5e8cd830"),
"adaptive_novelty_rule_anticipation_metrics.csv":(8074,"ff4b0ad4263a480d7ce02bc84040e686871b10abdc6552e4b26ccebf97097785"),
"adaptive_novelty_split_metrics.csv":(38377,"4230582d3062066d28c2a6d35da7cc6ca8bee657e9d6bcdee03a2b205ecbf352"),
"adaptive_novelty_target_ledger.csv":(24151026,"4e72f13912a69ae4182a9bda4a8de62e59fd4d67056bc42151d96f679ee1f569"),
"q90_checkpoint_2026-11-07.json":(1287,"3da9755582727ebe96747f7d3b7a9cdb27f1afea70ac02066fb5de54fd7b1ee8"),
"q90_feature_selection.json":(24620,"0e752f901f1d5f8f7c4b7d8436f38e3939ee2ab7018dc4229a0e1fddd3c08ed9"),
"q90_formula_catalog.csv":(80772093,"a61f77ede7136d4eb88a57932488590741fd0b84ace8307d5dd90c192d520586"),
"q90_formula_family_split_summary.json":(62214,"aff80ea4ed4204a55237ea626e2ee54d9816d648e879e9cef7bcc8ee27106f70"),
"q90_formula_metrics_manifest.json":(4555,"30ea0587f00fab25b06358a32aa01e6dd72b82ffa673dc99981c522cd1a95272"),
"q90_split_metrics.csv":(238901597,"3192a5ab2a64e8526321b6b5c322320dfc5636e337eadde573b5e27b0461ec2a"),
"q90_target_ledger.csv":(4852794,"553ea2519f109cf0913f86a43210481f7e9ac346128f18698d425036d4e1c120"),
}


def sha256_bytes(b: bytes) -> str: return hashlib.sha256(b).hexdigest()
def git_blob_sha1(b: bytes) -> str: return hashlib.sha1(f"blob {len(b)}\0".encode()+b).hexdigest()
def canonical_json(x) -> bytes: return json.dumps(x,sort_keys=True,separators=(",",":"),ensure_ascii=False).encode()
def ast_id(ast: dict) -> str: return "Q141A6-"+sha256_bytes(canonical_json(ast))

def verify_zip(path: Path):
    raw=path.read_bytes()
    if sha256_bytes(raw)!=EXPECTED["zip_sha256"]: raise RuntimeError("Q141_A6_BLOCKED: Q90 ZIP SHA-256 mismatch")
    with zipfile.ZipFile(path) as z:
        if z.testzip() is not None: raise RuntimeError("Q141_A6_BLOCKED: ZIP CRC failure")
        actual={n for n in z.namelist() if not n.endswith('/')}
        if actual!=set(MEMBERS): raise RuntimeError("Q141_A6_BLOCKED: source member set mismatch")
        verified=[]
        for n,(size,digest) in MEMBERS.items():
            data=z.read(n)
            if len(data)!=size or sha256_bytes(data)!=digest: raise RuntimeError(f"Q141_A6_BLOCKED: member digest mismatch: {n}")
            verified.append(n)
        return z,verified

def load_source(path: Path):
    with zipfile.ZipFile(path) as z:
        catalog=json.loads(z.read("adaptive_novelty_feature_catalog.json"))
        selection=json.loads(z.read("q90_feature_selection.json"))
        manifest=json.loads(z.read("q90_formula_metrics_manifest.json"))
        ledger_bytes=z.read("q90_target_ledger.csv")
        matrix_bytes=z.read("adaptive_novelty_feature_matrix.npz")
        if sha256_bytes(matrix_bytes)!=EXPECTED["matrix_sha256"]: raise RuntimeError("Q141_A6_BLOCKED: matrix SHA mismatch")
        if sha256_bytes(z.read("q90_formula_catalog.csv"))!=EXPECTED["catalog_sha256"]: raise RuntimeError("Q141_A6_BLOCKED: formula catalog SHA mismatch")
        if sha256_bytes(z.read("q90_feature_selection.json"))!=EXPECTED["selection_sha256"]: raise RuntimeError("Q141_A6_BLOCKED: feature selection SHA mismatch")
        if sha256_bytes(ledger_bytes)!=EXPECTED["ledger_sha256"]: raise RuntimeError("Q141_A6_BLOCKED: target ledger SHA mismatch")
        if sha256_bytes(z.read("q90_split_metrics.csv"))!=EXPECTED["split_metrics_sha256"]: raise RuntimeError("Q141_A6_BLOCKED: split metrics SHA mismatch")
        if sha256_bytes(z.read("adaptive_novelty_feature_catalog.json"))!=EXPECTED["feature_catalog_sha256"]: raise RuntimeError("Q141_A6_BLOCKED: feature catalog SHA mismatch")
        if manifest["archive"]["blob_sha"]!=EXPECTED["q90_archive_blob"] or manifest["archive"]["draw_count"]!=3401: raise RuntimeError("Q141_A6_BLOCKED: Q90 archive lineage mismatch")
        if manifest["q89_feature_matrix"]["shape"]!=[3351,40,59] or manifest["q89_feature_matrix"]["dtype"]!="float32": raise RuntimeError("Q141_A6_BLOCKED: feature matrix schema mismatch")
        if manifest["split_target_counts"]!=EXPECTED["split_counts"]: raise RuntimeError("Q141_A6_BLOCKED: split counts mismatch")
        if selection.get("selection_split")!="discovery" or len(selection.get("selected_features",[]))!=20: raise RuntimeError("Q141_A6_BLOCKED: selected-20 provenance mismatch")
        names=list(catalog["baseline_features"])+list(catalog["new_features"])
        fammap={n:"baseline" for n in catalog["baseline_features"]}
        fammap.update(catalog["new_feature_family_map"])
        if len(names)!=59 or len(set(names))!=59 or set(fammap)!=set(names): raise RuntimeError("Q141_A6_BLOCKED: 59-feature catalog mismatch")
        npz=np.load(__import__('io').BytesIO(matrix_bytes),allow_pickle=False)
        X=npz["feature_matrix"]
        dates=npz["target_dates"].astype(str)
        cutoffs=npz["cutoff_dates"].astype(str)
        actual=npz["actual_quintets"].astype(np.int16)
        matrix_names=npz["feature_names"].astype(str).tolist()
        archive_sha=str(npz["archive_blob_sha"].item())
        if X.shape!=(3351,40,59) or X.dtype!=np.float32 or not np.isfinite(X).all(): raise RuntimeError("Q141_A6_BLOCKED: invalid feature matrix")
        if matrix_names!=names: raise RuntimeError("Q141_A6_BLOCKED: matrix feature order differs from catalog")
        if archive_sha!=EXPECTED["q90_archive_blob"]: raise RuntimeError("Q141_A6_BLOCKED: matrix archive hash mismatch")
        if not np.all(dates>cutoffs) or not np.all(np.diff(dates.astype('datetime64[D]').astype('int64'))>0): raise RuntimeError("Q141_A6_BLOCKED: target/cutoff chronology invalid")
        if actual.shape!=(3351,5) or np.any(actual<1) or np.any(actual>40) or np.any(np.diff(np.sort(actual,axis=1),axis=1)<=0): raise RuntimeError("Q141_A6_BLOCKED: actual quintets invalid")
        rows=list(csv.DictReader(ledger_bytes.decode('utf-8').splitlines()))
        if len(rows)!=3351: raise RuntimeError("Q141_A6_BLOCKED: target ledger row count mismatch")
        for i,row in enumerate(rows):
            q=tuple(int(v) for v in row["actual_quintet"].split())
            if row["target_date"]!=dates[i] or row["cutoff_date"]!=cutoffs[i] or q!=tuple(sorted(actual[i].tolist())):
                raise RuntimeError(f"Q141_A6_BLOCKED: matrix/ledger target mismatch at row {i}")
            if int(row["prior_draws"])<50 or int(row["formula_count_tested"])!=330429: raise RuntimeError("Q141_A6_BLOCKED: prior draw or source formula count mismatch")
        splits=[r["split"] for r in rows]
        counts=dict(Counter(splits))
        if counts!=EXPECTED["split_counts"]: raise RuntimeError("Q141_A6_BLOCKED: target split coverage mismatch")
        selected=[x["feature"] for x in selection["selected_features"]]
        selected_indices=[names.index(n) for n in selected]
        family_by_idx={i:fammap[n] for i,n in enumerate(names)}
        return X,dates,cutoffs,actual,rows,names,family_by_idx,selected_indices,z,manifest


def pair_cover_quartets(indices, family_by_idx, nblocks, seed):
    combos=np.asarray(list(itertools.combinations(indices,4)),dtype=np.int16)
    pairs=list(itertools.combinations(indices,2)); pmap={p:i for i,p in enumerate(pairs)}
    pair_ids=np.asarray([[pmap[p] for p in itertools.combinations(row,2)] for row in combos],dtype=np.int32)
    diversity=np.asarray([len({family_by_idx[int(i)] for i in row}) for row in combos],dtype=np.int8)
    pair_counts=np.zeros(len(pairs),dtype=np.int16); feature_counts=np.zeros(59,dtype=np.int16)
    used=np.zeros(len(combos),dtype=bool); rng=np.random.default_rng(seed); chosen=[]
    for _ in range(nblocks):
        available=np.flatnonzero(~used)
        uncovered=(pair_counts[pair_ids[available]]==0).sum(axis=1)
        max_uncovered=int(uncovered.max())
        candidate_ids=available[uncovered==max_uncovered]
        fcost=feature_counts[combos[candidate_ids]].sum(axis=1)
        pcost=pair_counts[pair_ids[candidate_ids]].sum(axis=1)
        div=diversity[candidate_ids]
        jitter=rng.random(len(candidate_ids))
        order=np.lexsort((jitter,-div,pcost,fcost))
        pick=int(candidate_ids[order[0]])
        row=combos[pick].astype(int).tolist(); chosen.append(row); used[pick]=True
        feature_counts[row]+=1; pair_counts[pair_ids[pick]]+=1
    stats={"quartets":len(chosen),"pairs_total":len(pairs),"pairs_covered":int(np.sum(pair_counts>0)),"pair_count_min":int(pair_counts.min()),"pair_count_max":int(pair_counts.max()),"feature_use_min":int(feature_counts[list(indices)].min()),"feature_use_max":int(feature_counts[list(indices)].max()),"family_diversity_counts":dict(Counter(str(int(v)) for v in [len({family_by_idx[i] for i in q}) for q in chosen]))}
    if stats["pairs_covered"]!=len(pairs): raise RuntimeError(f"Q141_A6_BLOCKED: pair coverage incomplete {stats}")
    return chosen,pair_counts,feature_counts,stats


def balanced_linear_sets(indices, family_by_idx, n_per_size, seed, initial_feature_counts):
    rng=np.random.default_rng(seed); feature_counts=initial_feature_counts.copy()
    fam_names=sorted(set(family_by_idx[i] for i in indices)); fam_index={f:i for i,f in enumerate(fam_names)}
    fam_counts=np.zeros(len(fam_names),dtype=np.int32); chosen_by_size={}
    for k in SIZES:
        chosen=[]; chosen_set=set()
        for _ in range(n_per_size):
            batch=2000; m=len(indices)
            random_scores=rng.random((batch,m))
            loc=np.argpartition(random_scores,k-1,axis=1)[:,:k]
            candidates=np.sort(np.asarray(indices,dtype=np.int16)[loc],axis=1)
            candidates=np.unique(candidates,axis=0)
            keep=np.asarray([tuple(row.tolist()) not in chosen_set for row in candidates])
            candidates=candidates[keep]
            if len(candidates)==0: raise RuntimeError("Q141_A6_BLOCKED: linear subset sampler exhausted candidates")
            fcost=feature_counts[candidates].sum(axis=1)
            fam_load=np.asarray([sum(fam_counts[fam_index[family_by_idx[int(i)]]] for i in row) for row in candidates],dtype=np.int32)
            diversity=np.asarray([len({family_by_idx[int(i)] for i in row}) for row in candidates],dtype=np.int8)
            jitter=rng.random(len(candidates))
            order=np.lexsort((jitter,-diversity,fam_load,fcost))
            row=candidates[order[0]].astype(int).tolist(); chosen.append(row); chosen_set.add(tuple(row))
            feature_counts[row]+=1
            for i in row: fam_counts[fam_index[family_by_idx[i]]]+=1
        chosen_by_size[k]=chosen
    return chosen_by_size,feature_counts,{f:int(fam_counts[i]) for f,i in fam_index.items()}


def build_formulas(scope, quartets, linear_sets, names):
    formulas=[]
    for q in quartets:
        q=tuple(sorted(q)); base_id="SET-"+sha256_bytes(canonical_json([names[i] for i in q]))[:16]
        formulas.append(make_formula(scope,"linear_mean",q,names,base_id))
        for pair in itertools.combinations(q,2): formulas.append(make_formula(scope,"pairwise_interaction",q,names,base_id,pair=pair))
        for gate in q:
            for threshold in (0.5,1.0): formulas.append(make_formula(scope,"conditional_gate",q,names,base_id,gate=gate,threshold=threshold))
    for k,sets in linear_sets.items():
        for q in sets:
            q=tuple(sorted(q)); base_id="SET-"+sha256_bytes(canonical_json([names[i] for i in q]))[:16]
            formulas.append(make_formula(scope,"linear_mean",q,names,base_id))
    ids=[f["formula_id"] for f in formulas]
    asts=[f["ast_id"] for f in formulas]
    if len(ids)!=len(set(ids)) or len(asts)!=len(set(asts)): raise RuntimeError("Q141_A6_BLOCKED: duplicate formula or AST ID")
    return formulas


def make_formula(scope,typ,base,names,base_id,pair=None,gate=None,threshold=None):
    base=list(base)
    ast={"op":"per_number_score","base":{"op":"mean","feature_indices":base,"feature_names":[names[i] for i in base],"normalization":"per_target_zscore_across_40_candidates"}}
    if typ=="pairwise_interaction": ast={"op":"per_number_score","term":{"op":"add","terms":[ast["base"],{"op":"scale","coefficient":{"numerator":1,"denominator":4},"term":{"op":"candidate_zscore","term":{"op":"product","feature_indices":list(pair),"feature_names":[names[i] for i in pair]}}}]}}
    elif typ=="conditional_gate": ast={"op":"per_number_score","term":{"op":"add","terms":[ast["base"],{"op":"scale","coefficient":{"numerator":1,"denominator":4},"term":{"op":"indicator","condition":{"op":"greater_equal","feature_index":gate,"feature_name":names[gate],"threshold":{"numerator":1 if threshold==1.0 else 1,"denominator":1 if threshold==1.0 else 2}}}}]}}
    aid=ast_id(ast)
    if typ=="linear_mean": fid=f"L{len(base)}_"+"_".join(map(str,base))
    elif typ=="pairwise_interaction": fid=f"I4_"+"_".join(map(str,base))+f"_P{pair[0]}_{pair[1]}_W025"
    else: fid=f"G4_"+"_".join(map(str,base))+f"_F{gate}_T{int(threshold*10):02d}_B025"
    return {"formula_id":f"{scope}:{fid}","ast_id":aid,"scope":scope,"formula_type":typ,"formula_size":len(base),"feature_indices":base,"feature_names":[names[i] for i in base],"interaction_pair":list(pair) if pair else [],"gate_feature":gate,"gate_threshold":threshold,"base_set_id":base_id,"ast":ast}


def compile_formulas(formulas):
    n=len(formulas); base=np.full((n,8),-1,dtype=np.int16); size=np.zeros(n,dtype=np.int8); typ=np.zeros(n,dtype=np.int8); pair=np.full((n,2),-1,dtype=np.int16); gate=np.full(n,-1,dtype=np.int16); threshold=np.zeros(n,dtype=np.float64)
    for i,f in enumerate(formulas):
        ids=f["feature_indices"]; base[i,:len(ids)]=ids; size[i]=len(ids)
        if f["formula_type"]=="pairwise_interaction": typ[i]=1; pair[i]=f["interaction_pair"]
        elif f["formula_type"]=="conditional_gate": typ[i]=2; gate[i]=f["gate_feature"]; threshold[i]=f["gate_threshold"]
    return {"base":base,"size":size,"type":typ,"pair":pair,"gate":gate,"threshold":threshold}


def rank_target(Xrow, compiled):
    """Return candidate order only. Target outcome is deliberately not an argument."""
    X=np.asarray(Xrow,dtype=np.float64)
    if X.shape!=(40,59): raise ValueError("target feature matrix shape mismatch")
    n=len(compiled["size"]); scores=np.zeros((40,n),dtype=np.float64)
    for k in range(4,9):
        ix=np.flatnonzero((compiled["size"]==k)&(compiled["type"]!=1)&(compiled["type"]!=2))
        if len(ix): scores[:,ix]=X[:,compiled["base"][ix,:k]].mean(axis=2)
    ix=np.flatnonzero(compiled["type"]==1)
    if len(ix):
        p=compiled["pair"][ix]
        prod=X[:,p[:,0]]*X[:,p[:,1]]
        sd=prod.std(axis=0,ddof=0); mu=prod.mean(axis=0)
        z=np.divide(prod-mu,sd,out=np.zeros_like(prod),where=sd>0)
        scores[:,ix]=X[:,compiled["base"][ix,:4]].mean(axis=2)+0.25*z
    ix=np.flatnonzero(compiled["type"]==2)
    if len(ix):
        g=compiled["gate"][ix]
        bonus=(X[:,g]>=compiled["threshold"][ix][None,:]).astype(np.float64)
        scores[:,ix]=X[:,compiled["base"][ix,:4]].mean(axis=2)+0.25*bonus
    order=np.argsort(-np.round(scores.T,12),axis=1,kind="stable")
    return order, scores.T


def score_target(Xrow, compiled, actual):
    order,_=rank_target(Xrow,compiled)
    actual_mask=np.zeros(40,dtype=bool); actual_mask[np.asarray(actual,dtype=int)-1]=True
    h5=actual_mask[order[:,:5]].mean(axis=1)
    h10=actual_mask[order[:,:10]].mean(axis=1)
    h20=actual_mask[order[:,:20]].mean(axis=1)
    type_means={name:(float(h5[compiled["type"]==code].mean()) if np.any(compiled["type"]==code) else None) for name,code in (("linear_mean",0),("pairwise_interaction",1),("conditional_gate",2))}
    return {"top5":float(h5.mean()),"top10":float(h10.mean()),"top20":float(h20.mean()),"by_type_top5":type_means}


def select_q90_replay_formulas(zip_path: Path, seed=SEED, per_stratum=8):
    strata=[("linear_mean",k) for k in range(4,9)]+[("pairwise_interaction",4),("conditional_gate",4)]
    heaps={s:[] for s in strata}
    with zipfile.ZipFile(zip_path) as z, z.open("q90_formula_catalog.csv") as raw:
        import io
        reader=csv.DictReader(io.TextIOWrapper(raw,encoding="utf-8",newline=""))
        for row in reader:
            key=(row["formula_type"],int(row["formula_size"]))
            if key not in heaps: continue
            fid=row["formula_id"]; h=hashlib.sha256(f"{seed}:{fid}".encode()).hexdigest()
            arr=heaps[key]; item=(h,row)
            if len(arr)<per_stratum: arr.append(item); arr.sort(key=lambda x:x[0])
            elif h<arr[-1][0]: arr[-1]=item; arr.sort(key=lambda x:x[0])
    selected=[row for key in strata for _,row in heaps[key]]
    if len(selected)!=per_stratum*len(strata): raise RuntimeError("Q141_A6_BLOCKED: Q90 replay sample incomplete")
    ids={r["formula_id"] for r in selected}; metrics={}
    with zipfile.ZipFile(zip_path) as z, z.open("q90_split_metrics.csv") as raw:
        import io
        reader=csv.DictReader(io.TextIOWrapper(raw,encoding="utf-8",newline=""))
        for row in reader:
            if row["formula_id"] in ids: metrics[(row["formula_id"],row["split"])]=float(row["mean_number_hits_top5"])
    if len(metrics)!=len(ids)*3: raise RuntimeError("Q141_A6_BLOCKED: missing Q90 replay metrics")
    names=None
    with zipfile.ZipFile(zip_path) as z: names=list(json.loads(z.read("adaptive_novelty_feature_catalog.json"))["baseline_features"])+list(json.loads(z.read("adaptive_novelty_feature_catalog.json"))["new_features"])
    formulas=[]
    for row in selected:
        base=[int(v) for v in row["feature_indices"].split(";") if v]
        pair=[]
        if row["interaction_pair"]:
            pair=[names.index(n) for n in row["interaction_pair"].split("*")]
        gate=names.index(row["gate_feature"]) if row["gate_feature"] else None
        threshold=float(row["gate_threshold"]) if row["gate_threshold"] else None
        formulas.append({"formula_id":row["formula_id"],"formula_type":row["formula_type"],"feature_indices":base,"interaction_pair":pair,"gate_feature":gate,"gate_threshold":threshold})
    return formulas,metrics


def replay_audit(zip_path,X,actual,splits):
    formulas,expected=select_q90_replay_formulas(zip_path)
    comp=compile_formulas(formulas); per_formula={f["formula_id"]:[] for f in formulas}
    for t in range(len(X)):
        Xrow=np.asarray(X[t],dtype=np.float64)
        # Re-use score kernel but retain per-formula top-5 shares.
        n=len(formulas); scores=np.zeros((40,n),dtype=np.float64)
        for k in range(4,9):
            ix=np.flatnonzero((comp["size"]==k)&(comp["type"]==0))
            if len(ix): scores[:,ix]=Xrow[:,comp["base"][ix,:k]].mean(axis=2)
        ix=np.flatnonzero(comp["type"]==1)
        if len(ix):
            p=comp["pair"][ix]; prod=Xrow[:,p[:,0]]*Xrow[:,p[:,1]]; sd=prod.std(axis=0); mu=prod.mean(axis=0)
            z=np.divide(prod-mu,sd,out=np.zeros_like(prod),where=sd>0)
            scores[:,ix]=Xrow[:,comp["base"][ix,:4]].mean(axis=2)+0.25*z
        ix=np.flatnonzero(comp["type"]==2)
        if len(ix):
            g=comp["gate"][ix]; bonus=(Xrow[:,g]>=comp["threshold"][ix][None,:]).astype(float)
            scores[:,ix]=Xrow[:,comp["base"][ix,:4]].mean(axis=2)+0.25*bonus
        order=np.argsort(-np.round(scores.T,12),axis=1,kind="stable")
        mask=np.zeros(40,dtype=bool); mask[actual[t].astype(int)-1]=True
        h=mask[order[:,:5]].mean(axis=1)
        for j,f in enumerate(formulas): per_formula[f["formula_id"]].append(float(h[j]))
    split_indices={s:np.flatnonzero(np.asarray(splits)==s) for s in EXPECTED["split_counts"]}
    max_diff=0.0; checked=0; diffs=[]
    for fid,values in per_formula.items():
        a=np.asarray(values)
        for split,idx in split_indices.items():
            actual_mean=float(a[idx].mean()); expected_mean=expected[(fid,split)]
            diff=abs(actual_mean-expected_mean); max_diff=max(max_diff,diff); checked+=1
            diffs.append({"formula_id":fid,"split":split,"replayed":actual_mean,"source_metric":expected_mean,"abs_diff":diff})
    if max_diff>1e-12: raise RuntimeError(f"Q141_A6_BLOCKED: Q90 scoring replay mismatch {max_diff}")
    return {"formulas":len(formulas),"formula_split_comparisons":checked,"max_abs_difference":max_diff,"tolerance":1e-12,"status":"PASS"},diffs


def holm(pvals):
    order=np.argsort(pvals); out=np.ones(len(pvals)); running=0.0; m=len(pvals)
    for rank,i in enumerate(order): running=max(running,min(1.0,(m-rank)*float(pvals[i]))); out[i]=running
    return out.tolist()

def block_signflip(x,seed):
    x=np.asarray(x,dtype=np.float64); sums=np.asarray([x[i:i+BLOCK_LENGTH].sum() for i in range(0,len(x),BLOCK_LENGTH)])
    rng=np.random.default_rng(seed); signs=rng.choice(np.array([-1.0,1.0]),size=(BOOTSTRAP_REPLICATES,len(sums)))
    null=(signs@sums)/len(x); obs=float(x.mean())
    return float((1+np.count_nonzero(np.abs(null)>=abs(obs)-1e-15))/(BOOTSTRAP_REPLICATES+1)),len(sums)

def block_bootstrap_ci(x,seed):
    x=np.asarray(x,dtype=np.float64); n=len(x); blocks=math.ceil(n/BLOCK_LENGTH); rng=np.random.default_rng(seed); out=[]
    for start in range(0,BOOTSTRAP_REPLICATES,500):
        r=min(500,BOOTSTRAP_REPLICATES-start)
        starts=rng.integers(0,n,size=(r,blocks))
        ix=(starts[:,:,None]+np.arange(BLOCK_LENGTH)[None,None,:])%n
        sample=x[ix].reshape(r,-1)[:,:n]
        out.extend(sample.mean(axis=1).tolist())
    return [float(v) for v in np.quantile(np.asarray(out),[0.025,0.975])]


def write_csv(path,rows,fields):
    path.parent.mkdir(parents=True,exist_ok=True)
    with path.open("w",encoding="utf-8",newline="") as f:
        w=csv.DictWriter(f,fieldnames=fields,lineterminator="\n"); w.writeheader(); w.writerows(rows)
def write_json(path,obj): path.parent.mkdir(parents=True,exist_ok=True); path.write_text(json.dumps(obj,sort_keys=True,indent=2,ensure_ascii=False,allow_nan=False)+"\n",encoding="utf-8")
def file_info(path,root):
    b=path.read_bytes(); return {"path":str(path.relative_to(root)),"bytes":len(b),"sha256":sha256_bytes(b),"git_blob_sha1":git_blob_sha1(b)}


def run(zip_path:Path,out:Path):
    z,verified=verify_zip(zip_path)
    X,dates,cutoffs,actual,source_rows,names,families,selected_indices,_,manifest=load_source(zip_path)
    full_indices=list(range(59)); selected_indices=sorted(selected_indices)
    full_q,full_pc,full_fc,full_qstats=pair_cover_quartets(full_indices,families,N_QUARTETS,SEED)
    sel_q,sel_pc,sel_fc,sel_qstats=pair_cover_quartets(selected_indices,families,N_QUARTETS,SEED+1)
    full_lin,full_final_counts,full_family_counts=balanced_linear_sets(full_indices,families,LINEAR_PER_SIZE,SEED+2,full_fc)
    sel_lin,sel_final_counts,sel_family_counts=balanced_linear_sets(selected_indices,families,LINEAR_PER_SIZE,SEED+3,sel_fc)
    full_formulas=build_formulas("full59",full_q,full_lin,names)
    sel_formulas=build_formulas("selected20",sel_q,sel_lin,names)
    expected_count=N_QUARTETS*15+LINEAR_PER_SIZE*4
    if len(full_formulas)!=expected_count or len(sel_formulas)!=expected_count: raise RuntimeError("Q141_A6_BLOCKED: formula sample size mismatch")
    formulas=full_formulas+sel_formulas
    formula_path=out/"q141_a6_formula_catalog_2026-11-13.csv"
    formula_rows=[]
    for f in formulas:
        formula_rows.append({"formula_id":f["formula_id"],"ast_id":f["ast_id"],"scope":f["scope"],"formula_type":f["formula_type"],"formula_size":f["formula_size"],"feature_indices":";".join(map(str,f["feature_indices"])),"feature_names":"+".join(f["feature_names"]),"interaction_pair":"*".join(map(str,f["interaction_pair"])),"gate_feature":"" if f["gate_feature"] is None else f["gate_feature"],"gate_threshold":"" if f["gate_threshold"] is None else f["gate_threshold"],"base_set_id":f["base_set_id"]})
    write_csv(formula_path,formula_rows,list(formula_rows[0]))
    full_comp=compile_formulas(full_formulas); sel_comp=compile_formulas(sel_formulas)
    n=len(X); ledger=[]; full_vals=[]; sel_vals=[]; split_values=defaultdict(list); type_values=defaultdict(list)
    for t in range(n):
        f=score_target(X[t],full_comp,actual[t]); s=score_target(X[t],sel_comp,actual[t])
        delta=f["top5"]-s["top5"]
        row={"target_index":t,"target_date":str(dates[t]),"cutoff_date":str(cutoffs[t]),"prior_draws":int(source_rows[t]["prior_draws"]),"split":source_rows[t]["split"],"actual_quintet":" ".join(map(str,sorted(actual[t].tolist()))),"full59_formula_count":len(full_formulas),"selected20_formula_count":len(sel_formulas),"full59_top5_share":f["top5"],"selected20_top5_share":s["top5"],"delta_top5_full59_minus_selected20":delta,"full59_top10_share":f["top10"],"selected20_top10_share":s["top10"],"delta_top10":f["top10"]-s["top10"],"full59_top20_share":f["top20"],"selected20_top20_share":s["top20"],"delta_top20":f["top20"]-s["top20"],"full59_linear_top5":f["by_type_top5"]["linear_mean"],"full59_interaction_top5":f["by_type_top5"]["pairwise_interaction"],"full59_gate_top5":f["by_type_top5"]["conditional_gate"],"selected20_linear_top5":s["by_type_top5"]["linear_mean"],"selected20_interaction_top5":s["by_type_top5"]["pairwise_interaction"],"selected20_gate_top5":s["by_type_top5"]["conditional_gate"]}
        ledger.append(row); full_vals.append(f["top5"]); sel_vals.append(s["top5"]); split_values[row["split"]].append(row)
    ledger_path=out/"q141_a6_target_ledger_2026-11-13.csv"
    write_csv(ledger_path,ledger,list(ledger[0]))
    # Source formula replay against the original Q90 split metrics verifies scoring semantics.
    replay,diff_rows=replay_audit(zip_path,X,actual,[r["split"] for r in source_rows])
    split_summary={}
    for split in ("discovery","validation","blind_oos"):
        rows=split_values[split]
        f=np.asarray([r["full59_top5_share"] for r in rows]); s=np.asarray([r["selected20_top5_share"] for r in rows]); d=f-s
        split_summary[split]={"targets":len(rows),"full59_top5_mean":float(f.mean()),"selected20_top5_mean":float(s.mean()),"delta_top5":float(d.mean()),"full59_top10_mean":float(np.mean([r["full59_top10_share"] for r in rows])),"selected20_top10_mean":float(np.mean([r["selected20_top10_share"] for r in rows])),"full59_top20_mean":float(np.mean([r["full59_top20_share"] for r in rows])),"selected20_top20_mean":float(np.mean([r["selected20_top20_share"] for r in rows])),"full59_minus_uniform_top5":float(f.mean()-UNIFORM_TOP5)}
    blind=[r for r in ledger if r["split"]=="blind_oos"]
    d=np.asarray([r["delta_top5_full59_minus_selected20"] for r in blind],dtype=np.float64)
    u=np.asarray([r["full59_top5_share"]-UNIFORM_TOP5 for r in blind],dtype=np.float64)
    p1,k1=block_signflip(d,SEED+100); p2,k2=block_signflip(u,SEED+101)
    ci1=block_bootstrap_ci(d,SEED+200); ci2=block_bootstrap_ci(u,SEED+201)
    adj=holm([p1,p2])
    stats={"full59_minus_selected20_top5":{"mean":float(d.mean()),"ci95":ci1,"block_signflip_p_two_sided":p1,"holm_p":adj[0],"blocks":k1,"practical_threshold":PRACTICAL_THRESHOLD},"full59_minus_uniform_top5":{"mean":float(u.mean()),"ci95":ci2,"block_signflip_p_two_sided":p2,"holm_p":adj[1],"blocks":k2,"practical_threshold":PRACTICAL_THRESHOLD},"holm_family_size":2,"method":"non-overlapping 20-target block sign-flip; circular moving-block bootstrap 20,000 replicates; two-sided p-values; Holm across two registered Blind OOS endpoints"}
    decision="FULL59_COVERING_SAMPLE_LIFT_NOT_DEMONSTRATED"
    if d.mean()>=PRACTICAL_THRESHOLD and ci1[0]>0 and adj[0]<0.05: decision="FULL59_COVERING_SAMPLE_LIFT_DEMONSTRATED_HISTORICALLY_NOT_PROSPECTIVELY"
    report={"schema_version":"1.0","task_id":TASK,"status":"COMPLETED_HISTORICAL_WALK_FORWARD","decision":decision,"source":{"artifact_zip_sha256":EXPECTED["zip_sha256"],"q90_archive_blob_sha1":EXPECTED["q90_archive_blob"],"q90_draws":3401,"q90_cutoff":"2026-11-07","q141_archive_blob_sha1":EXPECTED["q141_archive_blob"],"q141_draws":3405,"q90_exact_prefix_of_q141":True,"q90_suffix_rows_excluded":4,"matrix_sha256":EXPECTED["matrix_sha256"],"matrix_shape":[3351,40,59],"matrix_dtype":"float32","feature_catalog_sha256":EXPECTED["feature_catalog_sha256"],"formula_catalog_sha256":EXPECTED["catalog_sha256"],"feature_selection_sha256":EXPECTED["selection_sha256"],"target_ledger_sha256":EXPECTED["ledger_sha256"],"split_metrics_sha256":EXPECTED["split_metrics_sha256"],"verified_zip_members":len(verified)},"design":{"seed":SEED,"quartets_per_scope":N_QUARTETS,"linear_subsets_per_size":LINEAR_PER_SIZE,"formula_count_per_scope":expected_count,"formula_count_total":len(formulas),"formula_types_per_scope":{"linear_mean":N_QUARTETS+LINEAR_PER_SIZE*4,"pairwise_interaction":N_QUARTETS*6,"conditional_gate":N_QUARTETS*8},"scope_feature_counts":{"full59":59,"selected20":20},"full59_pair_coverage":full_qstats,"selected20_pair_coverage":sel_qstats,"full59_linear_feature_use_min_max":[int(full_final_counts[full_indices].min()),int(full_final_counts[full_indices].max())],"selected20_linear_feature_use_min_max":[int(sel_final_counts[selected_indices].min()),int(sel_final_counts[selected_indices].max())],"full59_family_counts_in_added_linears":full_family_counts,"selected20_family_counts_in_added_linears":sel_family_counts},"walkforward":{"targets":len(ledger),"split_counts":dict(Counter(r["split"] for r in ledger)),"first_target":ledger[0]["target_date"],"last_target":ledger[-1]["target_date"],"strict_prior_cutoff_check":"all matrix cutoff_date values precede target_date; feature lineage is draws[:i] and state updates after scoring","blind_oos_label":"historical exposed; not virgin prospective evidence","split_summary":split_summary},"blind_oos_inference":stats,"q90_scoring_replay":replay,"limitations":["Q90 feature matrix is pinned to the 3,401-draw archive through 2026-11-07; four later Q141 rows are excluded.","The full59 and selected20 formula universes are deterministic samples, not exhaustive catalogs.","The selected20 control was selected using Q90 Discovery outcomes; it is a historical selected baseline, not a neutral random control.","The historical Blind OOS has been exposed to prior SONAR research and is not prospective virgin evidence.","This experiment measures per-number Top-5 ranking hit share averaged across formulas; it does not directly predict a five-number ticket or prove draw predictability.","The covering sample uses 350 quartets plus 75 linear subsets at each size 5–8; formulas are dependent through shared features and base sets."]}
    report_path=out/"q141_a6_full59_covering_report_2026-11-13.json"; write_json(report_path,report)
    # Manifest is deterministic and includes the exact code-independent outputs.
    manifest={"schema_version":"1.0","task_id":TASK,"source_artifact_sha256":EXPECTED["zip_sha256"],"source_members_verified":len(verified),"formula_sample":{"full59":len(full_formulas),"selected20":len(sel_formulas),"catalog_rows":len(formulas)},"target_rows":len(ledger),"outputs":[]}
    for pth,rows in ((formula_path,len(formula_rows)),(ledger_path,len(ledger)),(report_path,None)):
        info=file_info(pth,out); 
        if rows is not None: info["rows"]=rows
        manifest["outputs"].append(info)
    manifest_path=out/"q141_a6_full59_covering_manifest_2026-11-13.json"; write_json(manifest_path,manifest)
    checkpoint={"schema_version":"1.0","task_id":TASK,"status":"LOCAL_WALKFORWARD_AND_SOURCE_REPLAY_VERIFIED_PENDING_REMOTE_READBACK","source_zip_sha256":EXPECTED["zip_sha256"],"formula_catalog_sha256":manifest["outputs"][0]["sha256"],"target_ledger_sha256":manifest["outputs"][1]["sha256"],"report_sha256":manifest["outputs"][2]["sha256"],"source_members_verified":len(verified),"q90_replay":replay,"tests":{"strict_prior_dates":True,"matrix_ledger_reconciliation":True,"all59_feature_coverage":True,"all_pair_coverage":True,"deterministic_formula_ids":True},"decision":decision,"next_action":"Do not tune on historical Blind OOS. Extend Q89 feature lineage to a current archive only after a fresh strict-prior feature-matrix build and independent acceptance."}
    checkpoint_path=out/"q141_a6_full59_covering_checkpoint_2026-11-13.json"; write_json(checkpoint_path,checkpoint)
    return report,manifest,checkpoint,formula_path,ledger_path,report_path,manifest_path,checkpoint_path


def main():
    ap=argparse.ArgumentParser(); ap.add_argument("--zip",required=True); ap.add_argument("--output-dir",required=True); args=ap.parse_args()
    out=Path(args.output_dir); out.mkdir(parents=True,exist_ok=True)
    result=run(Path(args.zip),out)
    report=result[0]
    print(json.dumps({"status":report["status"],"decision":report["decision"],"walkforward":report["walkforward"],"blind_oos_inference":report["blind_oos_inference"],"q90_scoring_replay":report["q90_scoring_replay"],"outputs":[str(x) for x in result[3:]]},indent=2))
if __name__=="__main__": main()
