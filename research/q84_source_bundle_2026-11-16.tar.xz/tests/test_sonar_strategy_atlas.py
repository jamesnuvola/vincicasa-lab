#!/usr/bin/env python3
"""Regression and acceptance tests for Q84 event-level strategy atlas."""
from __future__ import annotations

import csv
import importlib.util
import random
import sys
import tempfile
import types
import unittest
from datetime import date, timedelta
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SCRIPTS = ROOT / "scripts"
sys.path.insert(0, str(SCRIPTS))

stub = types.ModuleType("sonar_sequence_agent")
stub.MIN_HISTORY = 200
stub.NUMBERS = tuple(range(1, 41))
stub.BASE_RULES = ("freq_a", "freq_b", "freq_c")
stub.CONFIGS = [
    ("freq_a", "family", ("freq_a",)),
    ("freq_b", "family", ("freq_b",)),
    ("PAIR::freq_a>freq_b", "pair", ("freq_a", "freq_b")),
    ("CHAIN::freq_a>freq_b>freq_c", "chain", ("freq_a", "freq_b", "freq_c")),
]


def _rank_numbers(scores):
    order = sorted(stub.NUMBERS, key=lambda n: (-float(scores[n]), n))
    return order, {n: i + 1 for i, n in enumerate(order)}


def _feature_scores(history):
    scores = {name: {} for name in stub.BASE_RULES}
    for n in stub.NUMBERS:
        scores["freq_a"][n] = sum(n in draw["nums"] for draw in history[-5:])
        scores["freq_b"][n] = sum(n in draw["nums"] for draw in history[-20:])
        scores["freq_c"][n] = sum(
            (1.0 / (lag + 1))
            for lag, draw in enumerate(reversed(history[-10:]))
            if n in draw["nums"]
        )
    return scores


def _combine_scores(base, sequence):
    rank_maps = {name: _rank_numbers(base[name])[1] for name in set(sequence)}
    weights = list(range(len(sequence), 0, -1))
    return {
        n: sum(weight * (41 - rank_maps[name][n]) for name, weight in zip(sequence, weights))
        for n in stub.NUMBERS
    }


def _cascade_rank(base, sequence):
    scores = _combine_scores(base, sequence)
    return _rank_numbers(scores)[0]


stub.rank_numbers = _rank_numbers
stub.feature_scores = _feature_scores
stub.combine_scores = _combine_scores
stub.cascade_rank = _cascade_rank
stub.read_draws = lambda: []
sys.modules["sonar_sequence_agent"] = stub

SPEC = importlib.util.spec_from_file_location("sonar_strategy_atlas", SCRIPTS / "sonar_strategy_atlas.py")
atlas = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(atlas)


def synthetic_draws(count: int):
    rng = random.Random(14084)
    start = date(2017, 1, 1)
    result = []
    for i in range(count):
        result.append({
            "date": start + timedelta(days=i),
            "nums": tuple(sorted(rng.sample(range(1, 41), 5))),
        })
    return result


class StrategyAtlasTests(unittest.TestCase):
    def test_pre_target_state_uses_only_prior_outcomes(self):
        start = date(2020, 1, 1)
        prior = [
            {"date": start + timedelta(days=i), "hits_top20": 3, "all5_top20": int(i >= 30)}
            for i in range(60)
        ]
        state = atlas.pre_target_state(prior, start + timedelta(days=60))
        self.assertEqual(state["prior_strategy_targets"], 60)
        self.assertEqual(state["pre_target_state"], "IMPROVING")
        self.assertTrue(state["state_detectable_before_target"])
        self.assertEqual(state["prior_top20_success_rate_50"], 0.6)

    def test_exact_paired_sign_test_and_holm(self):
        self.assertAlmostEqual(atlas.sign_test_two_sided(10, 0), 2 / 1024)
        self.assertEqual(atlas.sign_test_two_sided(4, 4), 1.0)
        self.assertGreater(atlas.sign_test_two_sided(1600, 1600), 0.99)
        adjusted = atlas.holm_adjust([("a", 0.001), ("b", 0.02), ("c", 0.5)])
        self.assertGreaterEqual(adjusted["a"], 0.001)
        self.assertGreaterEqual(adjusted["b"], adjusted["a"])
        self.assertEqual(adjusted["c"], 0.5)

    def test_full_rank_ledger_and_catalog_are_complete(self):
        draws = synthetic_draws(205)
        with tempfile.TemporaryDirectory() as temp:
            report = atlas.run(
                draws=draws,
                output_dir=Path(temp),
                reference_path=None,
                archive_bytes=b"synthetic-archive-for-q84",
            )
            ledger_path = Path(temp) / "strategy_atlas_target_ledger.csv"
            with ledger_path.open(newline="", encoding="utf-8") as handle:
                rows = list(csv.DictReader(handle))
            self.assertEqual(report["status"], "COMPUTED_PENDING_ACCEPTANCE_VALIDATION")
            self.assertEqual(report["scored_targets"], 5)
            self.assertEqual(report["target_ledger_rows"], 5 * len(stub.CONFIGS))
            self.assertEqual(len(rows), 5 * len(stub.CONFIGS))
            first_target = [r for r in rows if r["target_date"] == draws[200]["date"].isoformat()]
            self.assertEqual(len(first_target), len(stub.CONFIGS))
            for row in rows:
                ranking = [int(x) for x in row["ranking_order_1_to_40"].split()]
                actual = [int(x) for x in row["actual_quintet"].split()]
                ranks = __import__("json").loads(row["actual_number_ranks"])
                self.assertEqual(len(ranking), 40)
                self.assertEqual(set(ranking), set(range(1, 41)))
                rank_map = {n: i + 1 for i, n in enumerate(ranking)}
                self.assertEqual(ranks, [rank_map[n] for n in actual])
                self.assertLess(row["cutoff_date"], row["target_date"])
                self.assertEqual(row["evaluation_mode"], "STRICT_PRIOR_WALK_FORWARD")
            first = first_target[0]
            self.assertEqual(first["prior_strategy_targets"], "0")
            self.assertEqual(first["pre_target_state"], "WARMUP")
            self.assertEqual(first["state_detectable_before_target"], "False")

            with (Path(temp) / "strategy_atlas_catalog.jsonl").open(encoding="utf-8") as handle:
                catalog = [__import__("json").loads(line) for line in handle]
            self.assertEqual(len(catalog), len(stub.CONFIGS) + 6 + 1)
            retrospective = [r for r in catalog if r["record_type"] == "RETROSPECTIVE_ORACLE"]
            self.assertEqual(len(retrospective), 1)
            self.assertFalse(retrospective[0]["ex_ante_eligible"])
            self.assertNotIn("RETROSPECTIVE::Q80_BEST_PER_TARGET", {r["strategy_id"] for r in rows})

    def test_target_outcome_cannot_change_its_pre_target_ranking(self):
        draws_a = synthetic_draws(205)
        draws_b = list(draws_a)
        replacement = tuple(sorted({1, 8, 15, 22, 39}))
        draws_b[200] = {"date": draws_a[200]["date"], "nums": replacement}
        base_a = stub.feature_scores(draws_a[:200])
        base_b = stub.feature_scores(draws_b[:200])
        for config_id, kind, sequence in stub.CONFIGS:
            self.assertEqual(
                atlas.rank_config(base_a, kind, sequence),
                atlas.rank_config(base_b, kind, sequence),
                config_id,
            )


    def test_acceptance_validator_reconciles_full_synthetic_evidence(self):
        draws = synthetic_draws(205)
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            out = root / "reports" / "sequence_agent"
            out.mkdir(parents=True)
            data_path = root / "data" / "storico_daily.csv"
            data_path.parent.mkdir(parents=True)
            lines = ["data,n1,n2,n3,n4,n5"]
            for draw in draws:
                lines.append(
                    draw["date"].isoformat() + "," + ",".join(map(str, draw["nums"]))
                )
            archive_raw = ("\n".join(lines) + "\n").encode("utf-8")
            data_path.write_bytes(archive_raw)

            atlas.run(
                draws=draws,
                output_dir=out,
                reference_path=None,
                archive_bytes=archive_raw,
            )
            source = out / "strategy_atlas_target_ledger.csv"
            reference = out / "historical_rule_ledger.csv"
            with source.open(newline="", encoding="utf-8") as handle:
                rows = list(csv.DictReader(handle))
            with reference.open("w", newline="", encoding="utf-8") as handle:
                fields = [
                    "target_date", "history_cutoff", "config_id", "top20", "top10",
                    "top5", "actual_numbers", "hit_count", "top10_hit_count",
                    "top5_hit_count",
                ]
                writer = csv.DictWriter(handle, fieldnames=fields)
                writer.writeheader()
                for row in rows:
                    ranking = [int(x) for x in row["ranking_order_1_to_40"].split()]
                    writer.writerow({
                        "target_date": row["target_date"],
                        "history_cutoff": row["cutoff_date"],
                        "config_id": row["strategy_id"],
                        "top20": " ".join(map(str, ranking[:20])),
                        "top10": " ".join(map(str, ranking[:10])),
                        "top5": " ".join(map(str, ranking[:5])),
                        "actual_numbers": row["actual_quintet"],
                        "hit_count": row["hits_top20"],
                        "top10_hit_count": row["hits_top10"],
                        "top5_hit_count": row["hits_top5"],
                    })

            atlas.run(
                draws=draws,
                output_dir=out,
                reference_path=reference,
                archive_bytes=archive_raw,
            )
            validator_spec = importlib.util.spec_from_file_location(
                "validate_sonar_strategy_atlas", SCRIPTS / "validate_sonar_strategy_atlas.py"
            )
            validator = importlib.util.module_from_spec(validator_spec)
            validator_spec.loader.exec_module(validator)
            validator.ROOT = root
            validator.OUT = out
            validator.DATA = data_path
            validator.Q84_CATALOG = out / "strategy_atlas_catalog.jsonl"
            validator.Q84_LEDGER = out / "strategy_atlas_target_ledger.csv"
            validator.Q84_LIFECYCLE = out / "strategy_atlas_lifecycle.json"
            validator.Q84_REPORT = out / "strategy_atlas_report.json"
            validator.Q84_STRATEGY_METRICS = out / "strategy_atlas_strategy_metrics.csv"
            validator.Q84_PAIR_METRICS = out / "strategy_atlas_pair_metrics.csv"
            validator.Q84_CHECKPOINT = out / "strategy_atlas_checkpoint.json"
            validator.EXPECTED_STRATEGY_COUNT = len(stub.CONFIGS)
            errors = validator.validate_q84()
            self.assertEqual(errors, [])


if __name__ == "__main__":
    unittest.main(verbosity=2)
