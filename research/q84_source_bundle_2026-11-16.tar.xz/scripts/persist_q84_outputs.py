#!/usr/bin/env python3
"""Persist Q84 strategy-atlas evidence through Git Data API and verify exact bytes."""
from __future__ import annotations

import base64
import hashlib
import json
import os
import urllib.error
import urllib.request
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "reports" / "sequence_agent"
BRANCH = "research/per-number-condition-grammar-20261026"
API = "https://api.github.com"
PATHS = (
    "reports/sequence_agent/strategy_atlas_catalog.jsonl",
    "reports/sequence_agent/strategy_atlas_target_ledger.csv",
    "reports/sequence_agent/strategy_atlas_lifecycle.json",
    "reports/sequence_agent/strategy_atlas_report.json",
    "reports/sequence_agent/strategy_atlas_strategy_metrics.csv",
    "reports/sequence_agent/strategy_atlas_pair_metrics.csv",
    "reports/sequence_agent/strategy_atlas_checkpoint.json",
    "reports/sequence_agent/research_queue_status.json",
)


def api(method: str, path: str, payload=None):
    token = os.environ.get("GITHUB_TOKEN")
    repo = os.environ.get("GITHUB_REPOSITORY")
    if not token or not repo:
        raise SystemExit("Q84_PERSIST_BLOCKED: missing GitHub token/repository context")
    data = None if payload is None else json.dumps(
        payload, ensure_ascii=False, separators=(",", ":")
    ).encode("utf-8")
    request = urllib.request.Request(
        API + "/repos/" + repo + path,
        data=data,
        method=method,
        headers={
            "Accept": "application/vnd.github+json",
            "Authorization": "Bearer " + token,
            "X-GitHub-Api-Version": "2022-11-28",
            "Content-Type": "application/json",
            "User-Agent": "VinciCasa-SONAR-Q84-persistence",
        },
    )
    try:
        with urllib.request.urlopen(request, timeout=300) as response:
            raw = response.read()
    except urllib.error.HTTPError as exc:
        detail = exc.read().decode("utf-8", errors="replace")[:2000]
        raise SystemExit("Q84_PERSIST_BLOCKED: GitHub API " + str(exc.code) + " " + detail) from exc
    except Exception as exc:
        raise SystemExit("Q84_PERSIST_BLOCKED: GitHub API request failed: " + str(exc)) from exc
    return json.loads(raw.decode("utf-8")) if raw else {}


def sha256(raw: bytes) -> str:
    return hashlib.sha256(raw).hexdigest()


def main() -> None:
    branch = os.environ.get("GITHUB_REF_NAME") or os.environ.get("GITHUB_HEAD_REF")
    if branch != BRANCH:
        raise SystemExit("Q84_PERSIST_BLOCKED: refusing to write outside the registered research branch")

    report_path = OUT / "strategy_atlas_report.json"
    queue_path = OUT / "research_queue_status.json"
    report = json.loads(report_path.read_text(encoding="utf-8"))
    queue = json.loads(queue_path.read_text(encoding="utf-8"))
    task = next((item for item in queue.get("tasks", []) if item.get("id") == "Q84"), None)
    if report.get("task_id") != "Q84" or report.get("status") != "COMPUTED_PENDING_ACCEPTANCE_VALIDATION":
        raise SystemExit("Q84_PERSIST_BLOCKED: Q84 report is not in the expected pre-acceptance state")
    if report.get("review_status") != "PENDING_HUMAN_REVIEW_INTEGRATION":
        raise SystemExit("Q84_PERSIST_BLOCKED: human-review guard is missing")
    if queue.get("queue_status") != "QUEUE_VALID" or not task:
        raise SystemExit("Q84_PERSIST_BLOCKED: research queue is not valid or Q84 task is missing")
    if task.get("status") != "VALIDATED_PENDING_HUMAN_REVIEW" or task.get("validation_errors"):
        raise SystemExit("Q84_PERSIST_BLOCKED: Q84 acceptance validator did not pass")

    payloads = {}
    expected = {}
    for rel in PATHS:
        path = ROOT / rel
        if not path.is_file():
            raise SystemExit("Q84_PERSIST_BLOCKED: missing output " + rel)
        raw = path.read_bytes()
        payloads[rel] = raw
        expected[rel] = {"bytes": len(raw), "sha256": sha256(raw)}

    parent = api("GET", "/git/ref/heads/" + BRANCH)["object"]["sha"]
    base_tree = api("GET", "/git/commits/" + parent)["tree"]["sha"]
    tree_elements = []
    for rel, raw in payloads.items():
        blob = api(
            "POST",
            "/git/blobs",
            {"content": base64.b64encode(raw).decode("ascii"), "encoding": "base64"},
        )
        expected[rel]["blob_sha"] = blob["sha"]
        tree_elements.append({"path": rel, "mode": "100644", "type": "blob", "sha": blob["sha"]})

    tree = api("POST", "/git/trees", {"base_tree": base_tree, "tree": tree_elements})
    commit = api(
        "POST",
        "/git/commits",
        {
            "message": "Persist validated Q84 event-level strategy atlas and checkpoint [q84-persisted]",
            "tree": tree["sha"],
            "parents": [parent],
        },
    )

    current_parent = api("GET", "/git/ref/heads/" + BRANCH)["object"]["sha"]
    if current_parent != parent:
        raise SystemExit(
            "Q84_PERSIST_BLOCKED: branch advanced during persistence; refusing ref update"
        )
    api("PATCH", "/git/refs/heads/" + BRANCH, {"sha": commit["sha"], "force": False})

    committed = api("GET", "/git/commits/" + commit["sha"])
    tree_doc = api("GET", "/git/trees/" + committed["tree"]["sha"] + "?recursive=1")
    if tree_doc.get("truncated"):
        raise SystemExit("Q84_PERSIST_BLOCKED: exact-commit tree response was truncated")
    tree_map = {
        item["path"]: item
        for item in tree_doc.get("tree", [])
        if item.get("type") == "blob"
    }
    for rel, raw in payloads.items():
        entry = tree_map.get(rel)
        if (
            not entry
            or entry.get("sha") != expected[rel]["blob_sha"]
            or int(entry.get("size", -1)) != len(raw)
        ):
            raise SystemExit("Q84_PERSIST_BLOCKED: exact-commit tree mismatch for " + rel)
        blob = api("GET", "/git/blobs/" + entry["sha"])
        if blob.get("encoding") != "base64":
            raise SystemExit("Q84_PERSIST_BLOCKED: unexpected blob encoding for " + rel)
        reread = base64.b64decode(blob.get("content", ""))
        if reread != raw or sha256(reread) != expected[rel]["sha256"]:
            raise SystemExit("Q84_PERSIST_BLOCKED: exact-byte reread mismatch for " + rel)

    output = os.environ.get("GITHUB_OUTPUT")
    if output:
        with open(output, "a", encoding="utf-8") as handle:
            handle.write("commit_created=true\n")
            handle.write("commit_sha=" + commit["sha"] + "\n")
    print(
        json.dumps(
            {
                "task_id": "Q84",
                "persisted_head_sha": commit["sha"],
                "parent_sha": parent,
                "verified_file_count": len(payloads),
                "verified_bytes": sum(len(value) for value in payloads.values()),
                "all_exact_commit_bytes_verified": True,
                "review_status": "PENDING_HUMAN_REVIEW_INTEGRATION",
            },
            separators=(",", ":"),
        )
    )


if __name__ == "__main__":
    main()
