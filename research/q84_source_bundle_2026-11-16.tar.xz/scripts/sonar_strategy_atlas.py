#!/usr/bin/env python3
"""Q84 event-level strategy atlas.

Replays the registered 42 SONAR strategies with strict-prior histories, records
full 1..40 rankings, pre-target state, lifecycle events and paired strategy
relationships. Retrospective oracle entries are catalogued but never scored as
ex-ante forecasts.
"""
from __future__ import annotations

import csv
import hashlib
import itertools
import json
import math
import statistics
from collections import Counter, defaultdict
from datetime import date, datetime, timezone
from pathlib import Path
from statistics import NormalDist

import sonar_sequence_agent as engine

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / "data" / "storico_daily.csv"
OUT = ROOT / "reports" / "sequence_agent"
REFERENCE_LEDGER = OUT / "historical_rule_ledger.csv"

CATALOG = OUT / "strategy_atlas_catalog.jsonl"
TARGET_LEDGER = OUT / "strategy_atlas_target_ledger.csv"
LIFECYCLE = OUT / "strategy_atlas_lifecycle.json"
REPORT = OUT / "strategy_atlas_report.json"
CHECKPOINT = OUT / "strategy_atlas_checkpoint.json"

NUMBERS = tuple(range(1, 41))
SPLITS = ("discovery", "validation", "blind_oos")
STATE_LABELS = ("WARMUP", "IMPROVING", "DECLINING", "STABLE", "DORMANT")


def git_blob_sha1(raw: bytes) -> str:
    header = b"blob " + str(len(raw)).encode("ascii") + b"\0"
    return hashlib.sha1(header + raw).hexdigest()


def split_name(target_index: int, scored_targets: int, minimum_history: int) -> str:
    offset = target_index - minimum_history
    discovery_end = math.ceil(0.60 * scored_targets)
    validation_end = math.ceil(0.80 * scored_targets)
    if offset < discovery_end:
        return "discovery"
    if offset < validation_end:
        return "validation"
    return "blind_oos"


def rank_config(base_scores, config_type: str, sequence: tuple[str, ...]) -> list[int]:
    if config_type == "chain":
        ranked = list(engine.cascade_rank(base_scores, sequence))
    else:
        scores = base_scores[sequence[0]] if len(sequence) == 1 else engine.combine_scores(base_scores, sequence)
        ranked = list(engine.rank_numbers(scores)[0])
    if len(ranked) != 40 or set(ranked) != set(NUMBERS):
        raise ValueError(f"invalid 1..40 ranking for {config_type}:{sequence}")
    return ranked


def pre_target_state(prior_outcomes: list[dict], target_date: date) -> dict:
    """State is computed only from outcomes already observed before target_date."""
    n = len(prior_outcomes)
    last50 = prior_outcomes[-50:]
    last200 = prior_outcomes[-200:]
    rate50 = (sum(int(x["all5_top20"]) for x in last50) / len(last50)) if last50 else 0.0
    rate200 = (sum(int(x["all5_top20"]) for x in last200) / len(last200)) if last200 else 0.0
    mean_hits50 = (sum(int(x["hits_top20"]) for x in last50) / len(last50)) if last50 else 0.0
    last_success_index = next((i for i in range(n - 1, -1, -1) if prior_outcomes[i]["all5_top20"]), None)
    if last_success_index is None:
        since_success = n + 1
        days_since_success = None
        failure_streak = n
    else:
        since_success = n - 1 - last_success_index
        days_since_success = (target_date - prior_outcomes[last_success_index]["date"]).days
        failure_streak = since_success
    if n < 50:
        state = "WARMUP"
    elif since_success > 100:
        state = "DORMANT"
    elif rate50 > rate200 + 0.03:
        state = "IMPROVING"
    elif rate50 < rate200 - 0.03:
        state = "DECLINING"
    else:
        state = "STABLE"
    return {
        "prior_strategy_targets": n,
        "prior_top20_success_rate_50": rate50,
        "prior_top20_success_rate_200": rate200,
        "prior_top20_success_rate_delta_50_200": rate50 - rate200,
        "prior_mean_top20_hits_50": mean_hits50,
        "prior_failure_streak": failure_streak,
        "targets_since_last_top20_success": since_success,
        "days_since_last_top20_success": days_since_success,
        "pre_target_state": state,
        "state_detectable_before_target": n >= 50,
    }


def empty_stats() -> dict:
    return {
        "targets": 0,
        "hits_top5": 0,
        "hits_top10": 0,
        "hits_top20": 0,
        "rank_sum": 0,
        "all5_top5": 0,
        "all5_top10": 0,
        "all5_top20": 0,
    }


def update_stats(stats: dict, hits5: int, hits10: int, hits20: int, rank_sum: int) -> None:
    stats["targets"] += 1
    stats["hits_top5"] += hits5
    stats["hits_top10"] += hits10
    stats["hits_top20"] += hits20
    stats["rank_sum"] += rank_sum
    stats["all5_top5"] += int(hits5 == 5)
    stats["all5_top10"] += int(hits10 == 5)
    stats["all5_top20"] += int(hits20 == 5)


def binomial_upper_tail(successes: int, trials: int, probability: float) -> float:
    if trials <= 0:
        return 1.0
    if successes <= trials * probability:
        return 1.0
    if probability <= 0:
        return 0.0 if successes > 0 else 1.0
    if probability >= 1:
        return 1.0
    logp = (
        math.lgamma(trials + 1) - math.lgamma(successes + 1) - math.lgamma(trials - successes + 1)
        + successes * math.log(probability) + (trials - successes) * math.log1p(-probability)
    )
    total = math.exp(logp)
    for x in range(successes, trials):
        logp += math.log(trials - x) - math.log(x + 1) + math.log(probability) - math.log1p(-probability)
        total += math.exp(logp)
    return min(1.0, total)


def sign_test_two_sided(wins: int, losses: int) -> float:
    """Exact two-sided binomial sign test, stable for thousands of paired targets."""
    n = wins + losses
    if n == 0:
        return 1.0
    k = min(wins, losses)
    log_pk = (
        math.lgamma(n + 1) - math.lgamma(k + 1) - math.lgamma(n - k + 1)
        - n * math.log(2.0)
    )
    # Sum P(X=x) relative to P(X=k), walking down the lower tail.
    relative_sum = 1.0
    log_relative = 0.0
    for x in range(k, 0, -1):
        log_relative += math.log(x) - math.log(n - x + 1)
        relative_sum += math.exp(log_relative)
    lower_tail = math.exp(log_pk) * relative_sum
    return min(1.0, 2.0 * lower_tail)


def holm_adjust(items: list[tuple[str, float]]) -> dict[str, float]:
    ordered = sorted(items, key=lambda item: item[1])
    m = len(ordered)
    adjusted = {}
    running = 0.0
    for index, (key, p_value) in enumerate(ordered):
        value = min(1.0, (m - index) * max(0.0, min(1.0, p_value)))
        running = max(running, value)
        adjusted[key] = running
    return adjusted


def hypergeom_hit_rate_p_two_sided(total_hits: int, targets: int, top_k: int) -> float:
    """Conditional null: each target retains five distinct winners among 40 ranks."""
    if targets <= 0:
        return 1.0
    p = top_k / 40.0
    expected_per_target = 5.0 * p
    variance_per_target = 5.0 * p * (1.0 - p) * (40.0 - 5.0) / 39.0
    variance = targets * variance_per_target
    if variance <= 0:
        return 1.0
    z = (total_hits - targets * expected_per_target) / math.sqrt(variance)
    return min(1.0, 2.0 * (1.0 - NormalDist().cdf(abs(z))))


def exact_all5_baseline(top_k: int) -> float:
    return math.comb(top_k, 5) / math.comb(40, 5) if top_k >= 5 else 0.0


def metric_rows(aggregates: dict, strategy_ids: list[str]) -> tuple[list[dict], dict]:
    rows = []
    p_items = []
    endpoints = (("top5", 5), ("top10", 10), ("top20", 20))
    for strategy_id in strategy_ids:
        for split in SPLITS:
            stats = aggregates[strategy_id][split]
            n = stats["targets"]
            if not n:
                continue
            row = {
                "strategy_id": strategy_id,
                "split": split,
                "targets": n,
                "mean_number_hits_top5": stats["hits_top5"] / (n * 5),
                "mean_number_hits_top10": stats["hits_top10"] / (n * 5),
                "mean_number_hits_top20": stats["hits_top20"] / (n * 5),
                "mean_rank_of_actual_numbers": stats["rank_sum"] / (n * 5),
                "all5_top5_count": stats["all5_top5"],
                "all5_top10_count": stats["all5_top10"],
                "all5_top20_count": stats["all5_top20"],
                "all5_top5_rate": stats["all5_top5"] / n,
                "all5_top10_rate": stats["all5_top10"] / n,
                "all5_top20_rate": stats["all5_top20"] / n,
            }
            for endpoint, top_k in endpoints:
                number_hits = stats[f"hits_{endpoint}"]
                all5_hits = stats[f"all5_{endpoint}"]
                p_number = hypergeom_hit_rate_p_two_sided(number_hits, n, top_k)
                p_all5 = binomial_upper_tail(all5_hits, n, exact_all5_baseline(top_k))
                row[f"p_number_{endpoint}"] = p_number
                row[f"p_all5_{endpoint}"] = p_all5
                p_items.append((f"{strategy_id}|{split}|number|{endpoint}", p_number))
                p_items.append((f"{strategy_id}|{split}|all5|{endpoint}", p_all5))
            rows.append(row)
    adjusted = holm_adjust(p_items)
    for row in rows:
        sid, split = row["strategy_id"], row["split"]
        for endpoint, _ in endpoints:
            row[f"holm_number_{endpoint}"] = adjusted[f"{sid}|{split}|number|{endpoint}"]
            row[f"holm_all5_{endpoint}"] = adjusted[f"{sid}|{split}|all5|{endpoint}"]
    return rows, {
        "method": "Holm-Bonferroni",
        "family_size": len(p_items),
        "number_level_null": "per-target conditional hypergeometric null preserving five distinct winning numbers among 40 ranked positions; normal approximation for the sum",
        "all5_null": "exact binomial tail with per-target hypergeometric probability C(K,5)/C(40,5)",
    }


def pair_relationships(pair_stats: dict) -> tuple[list[dict], dict]:
    p_items = []
    for pair_id, stats in pair_stats.items():
        p_items.append((pair_id + "|hit_count_sign", sign_test_two_sided(stats["delta_wins"], stats["delta_losses"])))
        p_items.append((pair_id + "|all5_sign", sign_test_two_sided(stats["a_only_all5"], stats["b_only_all5"])))
    adjusted = holm_adjust(p_items)
    rows = []
    for pair_id, stats in pair_stats.items():
        a, b = stats["strategy_a"], stats["strategy_b"]
        p_hit = sign_test_two_sided(stats["delta_wins"], stats["delta_losses"])
        p_all5 = sign_test_two_sided(stats["a_only_all5"], stats["b_only_all5"])
        p_hit_adj = adjusted[pair_id + "|hit_count_sign"]
        p_all5_adj = adjusted[pair_id + "|all5_sign"]
        n = stats["targets"]
        jaccard = stats["top20_jaccard_sum"] / n if n else 0.0
        unique_total = stats["a_only_number_hits"] + stats["b_only_number_hits"]
        if p_hit_adj < 0.05 or p_all5_adj < 0.05:
            direction = (
                "ANTAGONISTIC_A_DOMINATES_B"
                if stats["delta_wins"] > stats["delta_losses"] or stats["a_only_all5"] > stats["b_only_all5"]
                else "ANTAGONISTIC_B_DOMINATES_A"
            )
        elif stats["exact_ranking_matches"] == n:
            direction = "EQUIVALENT"
        elif jaccard < 0.90 and unique_total > 0 and stats["a_only_number_hits"] > 0 and stats["b_only_number_hits"] > 0:
            direction = "COMPLEMENTARY_CANDIDATE"
        elif jaccard >= 0.95 and unique_total <= max(1, int(0.02 * n * 5)):
            direction = "REDUNDANT"
        else:
            direction = "UNRESOLVED"
        rows.append({
            "relationship_id": pair_id,
            "strategy_a": a,
            "strategy_b": b,
            "targets": n,
            "mean_top20_candidate_jaccard": jaccard,
            "exact_full_ranking_equivalence_rate": stats["exact_ranking_matches"] / n if n else 0.0,
            "top20_set_equivalence_rate": stats["top20_set_matches"] / n if n else 0.0,
            "a_marginal_unique_top20_hit_rate": stats["a_only_number_hits"] / (n * 5) if n else 0.0,
            "b_marginal_unique_top20_hit_rate": stats["b_only_number_hits"] / (n * 5) if n else 0.0,
            "a_only_actual_number_hits_top20": stats["a_only_number_hits"],
            "b_only_actual_number_hits_top20": stats["b_only_number_hits"],
            "both_actual_number_hits_top20": stats["both_number_hits"],
            "neither_actual_number_hits_top20": stats["neither_number_hits"],
            "a_only_all5_top20_targets": stats["a_only_all5"],
            "b_only_all5_top20_targets": stats["b_only_all5"],
            "top20_hit_count_delta_wins": stats["delta_wins"],
            "top20_hit_count_delta_losses": stats["delta_losses"],
            "top20_hit_count_delta_ties": stats["delta_ties"],
            "mean_top20_hit_count_delta_a_minus_b": (stats["a_only_number_hits"] - stats["b_only_number_hits"]) / n if n else 0.0,
            "paired_sign_p_hit_count": p_hit,
            "holm_p_hit_count": p_hit_adj,
            "paired_sign_p_all5": p_all5,
            "holm_p_all5": p_all5_adj,
            "relationship": direction,
            "interpretation": "Paired historical relationship only; not a causal or prospective claim.",
        })
    return rows, {
        "method": "Holm-Bonferroni over exact paired sign tests",
        "family_size": len(p_items),
        "conditional_null": "within each paired target, strategy labels are exchangeable under a symmetric paired-difference null; ties are excluded",
    }


def run(
    draws: list[dict] | None = None,
    output_dir: Path | None = None,
    reference_path: Path | None = None,
    archive_bytes: bytes | None = None,
) -> dict:
    output_dir = Path(output_dir or OUT)
    if draws is None:
        draws = engine.read_draws()
        archive_bytes = DATA.read_bytes()
    if archive_bytes is None:
        archive_bytes = b"synthetic-test-archive"
    minimum_history = int(engine.MIN_HISTORY)
    if len(draws) <= minimum_history:
        raise RuntimeError("Q84 requires more draws than the registered minimum history")
    strategy_configs = list(engine.CONFIGS)
    strategy_ids = [item[0] for item in strategy_configs]
    if len(strategy_ids) != len(set(strategy_ids)):
        raise RuntimeError("Q84 strategy IDs are not unique")
    scored_targets = len(draws) - minimum_history
    discovery_end = math.ceil(0.60 * scored_targets)
    validation_end = math.ceil(0.80 * scored_targets)
    split_counts = {
        "discovery": discovery_end,
        "validation": validation_end - discovery_end,
        "blind_oos": scored_targets - validation_end,
    }

    aggregates = {
        sid: {split: empty_stats() for split in ("overall",) + SPLITS}
        for sid in strategy_ids
    }
    state_aggregates = {
        sid: defaultdict(empty_stats)
        for sid in strategy_ids
    }
    prior_outcomes = {sid: [] for sid in strategy_ids}
    event_dates = {sid: {"top20": [], "top10": [], "top5": []} for sid in strategy_ids}
    event_indices = {sid: {"top20": [], "top10": [], "top5": []} for sid in strategy_ids}

    pair_stats = {}
    pair_ids = {}
    for a, b in itertools.combinations(strategy_ids, 2):
        digest = hashlib.sha256((a + "\0" + b).encode("utf-8")).hexdigest()[:16]
        pair_id = "REL_" + digest
        pair_ids[(a, b)] = pair_id
        pair_stats[pair_id] = {
            "strategy_a": a, "strategy_b": b, "targets": 0,
            "top20_jaccard_sum": 0.0,
            "exact_ranking_matches": 0,
            "top20_set_matches": 0,
            "a_only_number_hits": 0, "b_only_number_hits": 0,
            "both_number_hits": 0, "neither_number_hits": 0,
            "a_only_all5": 0, "b_only_all5": 0,
            "delta_wins": 0, "delta_losses": 0, "delta_ties": 0,
        }

    output_dir.mkdir(parents=True, exist_ok=True)
    ledger_fields = [
        "target_date", "cutoff_date", "prior_draws", "split", "strategy_id",
        "strategy_type", "rule_sequence", "actual_quintet", "ranking_order_1_to_40",
        "actual_number_ranks", "hits_top5", "hits_top10", "hits_top20",
        "all5_top5", "all5_top10", "all5_top20",
        "prior_strategy_targets", "prior_top20_success_rate_50",
        "prior_top20_success_rate_200", "prior_top20_success_rate_delta_50_200",
        "prior_mean_top20_hits_50", "prior_failure_streak",
        "targets_since_last_top20_success", "days_since_last_top20_success",
        "pre_target_state", "state_detectable_before_target", "evaluation_mode",
    ]

    parity_rows = 0
    ref_handle = None
    ref_reader = None
    if reference_path is not None:
        reference_path = Path(reference_path)
        if not reference_path.is_file():
            raise RuntimeError(f"Q84 reference ledger missing: {reference_path}")
        ref_handle = reference_path.open(newline="", encoding="utf-8-sig")
        ref_reader = iter(csv.DictReader(ref_handle))

    ledger_path = output_dir / TARGET_LEDGER.name
    try:
        with ledger_path.open("w", newline="", encoding="utf-8") as ledger_handle:
            writer = csv.DictWriter(ledger_handle, fieldnames=ledger_fields)
            writer.writeheader()
            for target_index in range(minimum_history, len(draws)):
                history = draws[:target_index]
                target = draws[target_index]
                target_date = target["date"]
                target_nums = tuple(target["nums"])
                cutoff = history[-1]["date"]
                split = split_name(target_index, scored_targets, minimum_history)
                base_scores = engine.feature_scores(history)

                rankings = {}
                actual_hit_sets = {}
                top20_masks = {}
                state_snapshots = {}
                for config_id, config_type, sequence in strategy_configs:
                    state = pre_target_state(prior_outcomes[config_id], target_date)
                    state_snapshots[config_id] = state
                    ranked = rank_config(base_scores, config_type, sequence)
                    rank_map = {number: index + 1 for index, number in enumerate(ranked)}
                    actual_ranks = [rank_map[number] for number in target_nums]
                    hits5 = sum(rank <= 5 for rank in actual_ranks)
                    hits10 = sum(rank <= 10 for rank in actual_ranks)
                    hits20 = sum(rank <= 20 for rank in actual_ranks)
                    all5_5 = hits5 == 5
                    all5_10 = hits10 == 5
                    all5_20 = hits20 == 5
                    rank_sum = sum(actual_ranks)
                    rankings[config_id] = ranked
                    actual_hit_sets[config_id] = {number for number, rank in zip(target_nums, actual_ranks) if rank <= 20}
                    top20_masks[config_id] = sum(1 << (number - 1) for number in ranked[:20])

                    update_stats(aggregates[config_id]["overall"], hits5, hits10, hits20, rank_sum)
                    update_stats(aggregates[config_id][split], hits5, hits10, hits20, rank_sum)
                    update_stats(state_aggregates[config_id][state["pre_target_state"]], hits5, hits10, hits20, rank_sum)

                    if all5_20:
                        event_dates[config_id]["top20"].append(target_date.isoformat())
                        event_indices[config_id]["top20"].append(target_index - minimum_history)
                    if all5_10:
                        event_dates[config_id]["top10"].append(target_date.isoformat())
                        event_indices[config_id]["top10"].append(target_index - minimum_history)
                    if all5_5:
                        event_dates[config_id]["top5"].append(target_date.isoformat())
                        event_indices[config_id]["top5"].append(target_index - minimum_history)

                    writer.writerow({
                        "target_date": target_date.isoformat(),
                        "cutoff_date": cutoff.isoformat(),
                        "prior_draws": target_index,
                        "split": split,
                        "strategy_id": config_id,
                        "strategy_type": config_type,
                        "rule_sequence": ">".join(sequence),
                        "actual_quintet": " ".join(map(str, target_nums)),
                        "ranking_order_1_to_40": " ".join(map(str, ranked)),
                        "actual_number_ranks": json.dumps(actual_ranks, separators=(",", ":")),
                        "hits_top5": hits5,
                        "hits_top10": hits10,
                        "hits_top20": hits20,
                        "all5_top5": int(all5_5),
                        "all5_top10": int(all5_10),
                        "all5_top20": int(all5_20),
                        **state,
                        "evaluation_mode": "STRICT_PRIOR_WALK_FORWARD",
                    })

                    if ref_reader is not None:
                        ref = next(ref_reader, None)
                        if ref is None:
                            raise RuntimeError("Q84 reference ledger ended before the recomputed ledger")
                        expected_top20 = " ".join(map(str, ranked[:20]))
                        expected_top10 = " ".join(map(str, ranked[:10]))
                        expected_top5 = " ".join(map(str, ranked[:5]))
                        checks = (
                            ref.get("target_date") == target_date.isoformat(),
                            ref.get("history_cutoff") == cutoff.isoformat(),
                            ref.get("config_id") == config_id,
                            ref.get("top20") == expected_top20,
                            ref.get("top10") == expected_top10,
                            ref.get("top5") == expected_top5,
                            ref.get("actual_numbers") == " ".join(map(str, target_nums)),
                            int(ref.get("hit_count", -1)) == hits20,
                            int(ref.get("top10_hit_count", -1)) == hits10,
                            int(ref.get("top5_hit_count", -1)) == hits5,
                        )
                        if not all(checks):
                            raise RuntimeError(
                                f"Q84 parity failure at {target_date.isoformat()} / {config_id}: "
                                f"{[i for i, ok in enumerate(checks) if not ok]}"
                            )
                        parity_rows += 1

                    prior_outcomes[config_id].append({
                        "date": target_date,
                        "hits_top20": hits20,
                        "all5_top20": int(all5_20),
                    })

                for (a, b), pair_id in pair_ids.items():
                    stats = pair_stats[pair_id]
                    hits_a = actual_hit_sets[a]
                    hits_b = actual_hit_sets[b]
                    a_only = len(hits_a - hits_b)
                    b_only = len(hits_b - hits_a)
                    both = len(hits_a & hits_b)
                    neither = 5 - a_only - b_only - both
                    delta = len(hits_a) - len(hits_b)
                    intersection = (top20_masks[a] & top20_masks[b]).bit_count()
                    union = 40 - intersection
                    stats["targets"] += 1
                    stats["top20_jaccard_sum"] += intersection / union if union else 1.0
                    stats["exact_ranking_matches"] += int(rankings[a] == rankings[b])
                    stats["top20_set_matches"] += int(top20_masks[a] == top20_masks[b])
                    stats["a_only_number_hits"] += a_only
                    stats["b_only_number_hits"] += b_only
                    stats["both_number_hits"] += both
                    stats["neither_number_hits"] += neither
                    if delta > 0:
                        stats["delta_wins"] += 1
                    elif delta < 0:
                        stats["delta_losses"] += 1
                    else:
                        stats["delta_ties"] += 1
                    if len(hits_a) == 5 and len(hits_b) < 5:
                        stats["a_only_all5"] += 1
                    elif len(hits_b) == 5 and len(hits_a) < 5:
                        stats["b_only_all5"] += 1

        if ref_handle is not None:
            if next(ref_reader, None) is not None:
                raise RuntimeError("Q84 reference ledger contains rows beyond the recomputed ledger")
            ref_handle.close()
            ref_handle = None
    finally:
        if ref_handle is not None:
            ref_handle.close()

    metric_table, metric_testing = metric_rows(aggregates, strategy_ids)
    pair_table, pair_testing = pair_relationships(pair_stats)

    metric_lookup = {(row["strategy_id"], row["split"]): row for row in metric_table}
    strategy_lifecycle = []
    catalog_records = []
    for config_id, config_type, sequence in strategy_configs:
        overall = aggregates[config_id]["overall"]
        top20_events = event_dates[config_id]["top20"]
        top20_indices = event_indices[config_id]["top20"]
        gaps = [b - a for a, b in zip(top20_indices, top20_indices[1:])]
        date_gaps = [
            (date.fromisoformat(b) - date.fromisoformat(a)).days
            for a, b in zip(top20_events, top20_events[1:])
        ]
        adjacent_repeats = sum(gap == 1 for gap in gaps)
        if not top20_events:
            lifecycle_class = "NULL_NO_ALL5_TOP20_EVENTS"
        elif len(top20_events) == 1:
            lifecycle_class = "ONE_TARGET"
        elif adjacent_repeats:
            lifecycle_class = "INTERMITTENT_WITH_ADJACENT_REPEATS"
        else:
            lifecycle_class = "INTERMITTENT_ISOLATED"
        state_rows = []
        overall_rate = overall["all5_top20"] / max(1, overall["targets"])
        for state_name in STATE_LABELS:
            s = state_aggregates[config_id].get(state_name, empty_stats())
            state_rate = s["all5_top20"] / max(1, s["targets"])
            state_rows.append({
                "state": state_name,
                "targets": s["targets"],
                "all5_top20_count": s["all5_top20"],
                "all5_top20_rate": state_rate,
                "mean_top20_number_hits": s["hits_top20"] / max(1, s["targets"]),
                "descriptive_lift_vs_strategy_overall": state_rate - overall_rate,
                "inference": "DESCRIPTIVE_ONLY_NO_STATE_PROMOTION",
            })
        conditional_candidates = [
            row for row in state_rows
            if row["targets"] >= 30 and row["descriptive_lift_vs_strategy_overall"] >= 0.05
        ]
        blind = metric_lookup.get((config_id, "blind_oos"), {})
        blind_null = (
            blind.get("holm_number_top20", 1.0) >= 0.05
            and blind.get("holm_all5_top20", 1.0) >= 0.05
        )
        strategy_lifecycle.append({
            "strategy_id": config_id,
            "strategy_type": config_type,
            "rule_sequence": list(sequence),
            "targets": overall["targets"],
            "top20_all5_event_count": len(top20_events),
            "top20_all5_event_dates": top20_events,
            "top20_event_gaps_in_targets": gaps,
            "top20_event_gaps_in_calendar_days": date_gaps,
            "median_gap_targets": statistics.median(gaps) if gaps else None,
            "median_gap_calendar_days": statistics.median(date_gaps) if date_gaps else None,
            "adjacent_repeat_episodes": adjacent_repeats,
            "lifecycle_class": lifecycle_class,
            "state_condition_metrics": state_rows,
            "conditional_state_candidates": conditional_candidates,
            "blind_oos_classification": "NULL_AFTER_HOLM" if blind_null else "EXPLORATORY_SIGNAL_UNVALIDATED",
            "blind_oos_metrics": blind,
        })
        catalog_records.append({
            "strategy_id": config_id,
            "record_type": "BASE_STRATEGY",
            "strategy_type": config_type,
            "rule_sequence": list(sequence),
            "formula_provenance": {
                "engine_module": "scripts/sonar_sequence_agent.py",
                "registered_config_id": config_id,
                "base_rule_names": list(sequence),
                "ranking_method": "family score ranking, ordinal-rank ensemble, or ordered cascade as registered",
            },
            "ex_ante_eligible": True,
            "evaluation_mode": "STRICT_PRIOR_WALK_FORWARD",
            "lifecycle_class": lifecycle_class,
            "conditional_state_candidates": conditional_candidates,
            "blind_oos_classification": "NULL_AFTER_HOLM" if blind_null else "EXPLORATORY_SIGNAL_UNVALIDATED",
        })

    pair_catalog_records = []
    for row in pair_table:
        record = {
            "strategy_id": row["relationship_id"],
            "record_type": "PAIR_RELATIONSHIP",
            "strategy_type": row["relationship"],
            "member_strategy_ids": [row["strategy_a"], row["strategy_b"]],
            "formula_provenance": {
                "relationship_rule": "paired actual-number Top20 hit complementarity and candidate-set Jaccard",
                "source_strategy_ids": [row["strategy_a"], row["strategy_b"]],
            },
            "ex_ante_eligible": False,
            "evaluation_mode": "PAIRED_HISTORICAL_RELATIONSHIP_AUDIT",
            "relationship_metrics": row,
        }
        pair_catalog_records.append(record)

    retrospective_record = {
        "strategy_id": "RETROSPECTIVE::Q80_BEST_PER_TARGET",
        "record_type": "RETROSPECTIVE_ORACLE",
        "strategy_type": "retrospective",
        "formula_provenance": {
            "source_file": "reports/sequence_agent/per_number_condition_target_ledger.csv",
            "selection_field": "best_formula_id",
            "selection_rule": "formula chosen after observing the target's actual winning-number ranks",
        },
        "ex_ante_eligible": False,
        "evaluation_mode": "RETROSPECTIVE_ORACLE_ONLY",
        "guardrail": "Never counted as an ex-ante forecast or included in the Q84 target ledger.",
    }
    catalog_records = catalog_records + pair_catalog_records + [retrospective_record]
    with (output_dir / CATALOG.name).open("w", encoding="utf-8", newline="") as handle:
        for record in catalog_records:
            handle.write(json.dumps(record, ensure_ascii=False, separators=(",", ":")) + "\n")

    lifecycle_payload = {
        "schema_version": "1.0",
        "task_id": "Q84",
        "status": "COMPUTED_PENDING_ACCEPTANCE_VALIDATION",
        "strategy_lifecycle": strategy_lifecycle,
        "pair_relationships": pair_table,
        "multiple_testing": {
            "strategy_performance": metric_testing,
            "pairwise_relationships": pair_testing,
        },
        "conditional_state_policy": "State metrics are computed from prior outcomes only; conditional candidates are descriptive and are not promoted.",
        "retrospective_policy": "Q80 best-per-target is catalogued separately and excluded from ex-ante target rows.",
    }
    (output_dir / LIFECYCLE.name).write_text(
        json.dumps(lifecycle_payload, indent=2, ensure_ascii=False) + "\n", encoding="utf-8"
    )

    metric_fields = list(metric_table[0].keys()) if metric_table else []
    if metric_fields:
        with (output_dir / "strategy_atlas_strategy_metrics.csv").open("w", newline="", encoding="utf-8") as handle:
            writer = csv.DictWriter(handle, fieldnames=metric_fields)
            writer.writeheader()
            writer.writerows(metric_table)

    pair_fields = list(pair_table[0].keys()) if pair_table else []
    if pair_fields:
        with (output_dir / "strategy_atlas_pair_metrics.csv").open("w", newline="", encoding="utf-8") as handle:
            writer = csv.DictWriter(handle, fieldnames=pair_fields)
            writer.writeheader()
            writer.writerows(pair_table)

    archive_sha1 = git_blob_sha1(archive_bytes)
    archive_sha256 = hashlib.sha256(archive_bytes).hexdigest()
    report = {
        "schema_version": "1.0",
        "task_id": "Q84",
        "status": "COMPUTED_PENDING_ACCEPTANCE_VALIDATION",
        "review_status": "PENDING_HUMAN_REVIEW_INTEGRATION",
        "source_archive": "data/storico_daily.csv",
        "source_archive_git_blob_sha1": archive_sha1,
        "source_archive_sha256": archive_sha256,
        "target_count": len(draws),
        "first_date": draws[0]["date"].isoformat(),
        "last_date": draws[-1]["date"].isoformat(),
        "latest_quintet": list(draws[-1]["nums"]),
        "minimum_prior_history": minimum_history,
        "scored_targets": scored_targets,
        "strategy_count": len(strategy_configs),
        "base_strategy_count": len(strategy_configs),
        "pair_relationship_count": len(pair_table),
        "retrospective_catalog_count": 1,
        "catalog_record_count": len(catalog_records),
        "target_ledger_rows": scored_targets * len(strategy_configs),
        "reference_ledger_parity_rows": parity_rows,
        "split_counts": split_counts,
        "formula_grammar_boundary": {
            "base_rule_count": len(engine.BASE_RULES),
            "pair_ensemble_count": sum(1 for _, kind, _ in strategy_configs if kind == "pair"),
            "ordered_chain_count": sum(1 for _, kind, _ in strategy_configs if kind == "chain"),
            "registered_strategy_count": len(strategy_configs),
            "description": "Finite registered SONAR rule grammar only; this does not exhaust mathematical formulas or the Q80-Q88 per-number formula universes.",
        },
        "uniform_baselines": {
            "number_hit_rate_top5": 0.125,
            "number_hit_rate_top10": 0.25,
            "number_hit_rate_top20": 0.5,
            "all5_top5": exact_all5_baseline(5),
            "all5_top10": exact_all5_baseline(10),
            "all5_top20": exact_all5_baseline(20),
            "mean_rank_of_actual_numbers": 20.5,
        },
        "multiple_testing": {
            "strategy_performance_family_size": metric_testing["family_size"],
            "pairwise_relationship_family_size": pair_testing["family_size"],
            "strategy_method": metric_testing["method"],
            "pairwise_method": pair_testing["method"],
        },
        "result_summary": {
            "strategies_with_any_all5_top20_event": sum(bool(event_dates[sid]["top20"]) for sid in strategy_ids),
            "strategies_with_no_all5_top20_event": sum(not event_dates[sid]["top20"] for sid in strategy_ids),
            "pair_relationship_counts": dict(Counter(row["relationship"] for row in pair_table)),
            "blind_oos_strategies_with_holm_number_top20_below_0_05": sum(
                metric_lookup.get((sid, "blind_oos"), {}).get("holm_number_top20", 1.0) < 0.05
                for sid in strategy_ids
            ),
            "blind_oos_strategies_with_holm_all5_top20_below_0_05": sum(
                metric_lookup.get((sid, "blind_oos"), {}).get("holm_all5_top20", 1.0) < 0.05
                for sid in strategy_ids
            ),
        },
        "outputs": {
            "catalog": "reports/sequence_agent/strategy_atlas_catalog.jsonl",
            "target_ledger": "reports/sequence_agent/strategy_atlas_target_ledger.csv",
            "lifecycle": "reports/sequence_agent/strategy_atlas_lifecycle.json",
            "report": "reports/sequence_agent/strategy_atlas_report.json",
            "strategy_metrics": "reports/sequence_agent/strategy_atlas_strategy_metrics.csv",
            "pair_metrics": "reports/sequence_agent/strategy_atlas_pair_metrics.csv",
            "checkpoint": "reports/sequence_agent/strategy_atlas_checkpoint.json",
        },
        "guardrails": [
            "Each target uses only the complete strict-prior history; the target draw is read only after all strategy rankings are constructed.",
            "Every ex-ante strategy ranks all 40 numbers; actual ranks are reconciled to the canonical target quintet.",
            "Pre-target state uses only earlier outcomes for the same strategy.",
            "Retrospective best-per-target is catalogued but excluded from ex-ante scoring and target rows.",
            "Null and failed strategies are retained; no strategy is promoted automatically.",
            "The registered 42-strategy grammar is finite and does not exhaust all mathematical formulas.",
            "Immutable historical and prospective freezes are never read for writing, reconstructed, or overwritten.",
        ],
    }
    report_path = output_dir / REPORT.name
    report_path.write_text(json.dumps(report, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")

    output_paths = [
        output_dir / CATALOG.name,
        ledger_path,
        output_dir / LIFECYCLE.name,
        report_path,
        output_dir / "strategy_atlas_strategy_metrics.csv",
        output_dir / "strategy_atlas_pair_metrics.csv",
    ]
    checkpoint = {
        "schema_version": "1.0",
        "task_id": "Q84",
        "status": "COMPUTED_PENDING_ACCEPTANCE_VALIDATION",
        "source_archive_git_blob_sha1": archive_sha1,
        "source_archive_sha256": archive_sha256,
        "target_count": len(draws),
        "last_date": draws[-1]["date"].isoformat(),
        "scored_targets": scored_targets,
        "strategy_count": len(strategy_configs),
        "target_ledger_rows": scored_targets * len(strategy_configs),
        "catalog_record_count": len(catalog_records),
        "reference_ledger_parity_rows": parity_rows,
        "outputs_sha256": {
            path.name: hashlib.sha256(path.read_bytes()).hexdigest()
            for path in output_paths
        },
        "generated_at_utc": datetime.now(timezone.utc).isoformat(),
    }
    (output_dir / CHECKPOINT.name).write_text(
        json.dumps(checkpoint, indent=2, ensure_ascii=False) + "\n", encoding="utf-8"
    )
    print("SONAR_Q84_REPORT_BEGIN")
    print(json.dumps(report, separators=(",", ":"), ensure_ascii=False))
    print("SONAR_Q84_REPORT_END")
    print("SONAR_Q84_CHECKPOINT_BEGIN")
    print(json.dumps(checkpoint, separators=(",", ":"), ensure_ascii=False))
    print("SONAR_Q84_CHECKPOINT_END")
    return report


def main() -> None:
    report = run(reference_path=REFERENCE_LEDGER)
    if report["status"] != "COMPUTED_PENDING_ACCEPTANCE_VALIDATION":
        raise SystemExit("Q84 output generation did not finish")


if __name__ == "__main__":
    main()
