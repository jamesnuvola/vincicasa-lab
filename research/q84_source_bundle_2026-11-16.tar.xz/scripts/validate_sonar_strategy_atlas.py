#!/usr/bin/env python3
"""Fail-closed Q84 event-level strategy-atlas acceptance validator."""
from __future__ import annotations

import csv
import hashlib
import json
import math
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "reports" / "sequence_agent"
DATA = ROOT / "data" / "storico_daily.csv"
Q84_CATALOG = OUT / "strategy_atlas_catalog.jsonl"
Q84_LEDGER = OUT / "strategy_atlas_target_ledger.csv"
Q84_LIFECYCLE = OUT / "strategy_atlas_lifecycle.json"
Q84_REPORT = OUT / "strategy_atlas_report.json"
Q84_STRATEGY_METRICS = OUT / "strategy_atlas_strategy_metrics.csv"
Q84_PAIR_METRICS = OUT / "strategy_atlas_pair_metrics.csv"
Q84_CHECKPOINT = OUT / "strategy_atlas_checkpoint.json"
Q80_SPLITS = ("discovery", "validation", "blind_oos")
EXPECTED_STRATEGY_COUNT = 42


def load_json(path: Path):
    return json.loads(path.read_text(encoding="utf-8"))


def load_csv(path: Path):
    with path.open(newline="", encoding="utf-8-sig") as handle:
        reader = csv.DictReader(handle)
        return reader.fieldnames or [], list(reader)


def add_error(errors: list[str], condition: bool, message: str) -> None:
    if not condition:
        errors.append(message)


def validate_q84():
    errors = []
    report = load_json(Q84_REPORT)
    with Q84_CATALOG.open(encoding="utf-8") as handle:
        catalog = [json.loads(line) for line in handle if line.strip()]
    ledger_fields, ledger_rows = load_csv(Q84_LEDGER)
    lifecycle = load_json(Q84_LIFECYCLE)
    checkpoint = load_json(Q84_CHECKPOINT)
    metric_fields, metric_rows = load_csv(Q84_STRATEGY_METRICS)
    pair_fields, pair_rows = load_csv(Q84_PAIR_METRICS)

    with DATA.open(newline="", encoding="utf-8-sig") as handle:
        archive = list(csv.DictReader(handle))
    raw = DATA.read_bytes()
    git_sha = hashlib.sha1(b"blob " + str(len(raw)).encode("ascii") + b"\0" + raw).hexdigest()
    sha256 = hashlib.sha256(raw).hexdigest()
    minimum = int(report.get("minimum_prior_history", 0))
    scored = max(0, len(archive) - minimum)
    strategy_count = int(report.get("strategy_count", 0))
    expected_pairs = math.comb(strategy_count, 2) if strategy_count >= 2 else 0
    expected_rows = scored * strategy_count
    discovery_end = math.ceil(.60 * scored)
    validation_end = math.ceil(.80 * scored)
    expected_splits = {
        "discovery": discovery_end,
        "validation": validation_end - discovery_end,
        "blind_oos": scored - validation_end,
    }

    add_error(errors, report.get("task_id") == "Q84", "Q84 report task id mismatch")
    add_error(errors, report.get("status") == "COMPUTED_PENDING_ACCEPTANCE_VALIDATION",
              "Q84 report is not awaiting acceptance validation")
    add_error(errors, report.get("review_status") == "PENDING_HUMAN_REVIEW_INTEGRATION",
              "Q84 human-review gate missing")
    add_error(errors, checkpoint.get("task_id") == "Q84" and
              checkpoint.get("status") == "COMPUTED_PENDING_ACCEPTANCE_VALIDATION",
              "Q84 checkpoint state mismatch")
    add_error(errors, checkpoint.get("source_archive_git_blob_sha1") == git_sha and
              checkpoint.get("source_archive_sha256") == sha256,
              "Q84 checkpoint archive lineage mismatch")
    add_error(errors, checkpoint.get("target_count") == len(archive) and
              checkpoint.get("scored_targets") == scored,
              "Q84 checkpoint target coverage mismatch")
    checkpoint_hashes = checkpoint.get("outputs_sha256", {})
    for output_path in (Q84_CATALOG, Q84_LEDGER, Q84_LIFECYCLE, Q84_REPORT,
                        Q84_STRATEGY_METRICS, Q84_PAIR_METRICS):
        expected_hash = checkpoint_hashes.get(output_path.name)
        if not expected_hash or hashlib.sha256(output_path.read_bytes()).hexdigest() != expected_hash:
            errors.append("Q84 checkpoint output SHA-256 mismatch: " + output_path.name)
    add_error(errors, minimum == 200, "Q84 registered minimum history mismatch")
    add_error(errors, report.get("source_archive_git_blob_sha1") == git_sha,
              "Q84 canonical archive Git blob SHA mismatch")
    add_error(errors, report.get("source_archive_sha256") == sha256,
              "Q84 canonical archive SHA-256 mismatch")
    add_error(errors, report.get("target_count") == len(archive), "Q84 target count mismatch")
    add_error(errors, report.get("scored_targets") == scored, "Q84 scored target count mismatch")
    add_error(errors, report.get("first_date") == archive[0]["data"] and
              report.get("last_date") == archive[-1]["data"], "Q84 archive date boundary mismatch")
    latest = archive[-1]
    latest_quintet = [int(latest["n" + str(i)]) for i in range(1, 6)]
    add_error(errors, report.get("latest_quintet") == latest_quintet, "Q84 latest quintet mismatch")
    add_error(errors, report.get("split_counts") == expected_splits,
              "Q84 chronological split counts mismatch")
    add_error(errors, report.get("target_ledger_rows") == expected_rows,
              "Q84 target ledger row count declaration mismatch")
    add_error(errors, report.get("reference_ledger_parity_rows") == expected_rows,
              "Q84 reference-ledger parity coverage mismatch")
    add_error(errors, strategy_count == EXPECTED_STRATEGY_COUNT, "Q84 registered strategy count mismatch")
    add_error(errors, report.get("pair_relationship_count") == expected_pairs,
              "Q84 pair relationship count mismatch")
    add_error(errors, report.get("catalog_record_count") == len(catalog),
              "Q84 catalog record count mismatch")
    add_error(errors, report.get("retrospective_catalog_count") == 1,
              "Q84 retrospective oracle catalog entry missing")

    base_records = [item for item in catalog if item.get("record_type") == "BASE_STRATEGY"]
    pair_records = [item for item in catalog if item.get("record_type") == "PAIR_RELATIONSHIP"]
    retrospective = [item for item in catalog if item.get("record_type") == "RETROSPECTIVE_ORACLE"]
    strategy_ids = [item.get("strategy_id") for item in base_records]
    add_error(errors, len(base_records) == strategy_count and len(set(strategy_ids)) == strategy_count,
              "Q84 base strategy catalog is incomplete or duplicated")
    add_error(errors, len(pair_records) == expected_pairs, "Q84 pair relationship catalog is incomplete")
    add_error(errors, len(retrospective) == 1 and retrospective[0].get("ex_ante_eligible") is False,
              "Q84 retrospective strategy is not explicitly excluded from ex-ante use")
    add_error(errors, "RETROSPECTIVE::Q80_BEST_PER_TARGET" not in set(strategy_ids),
              "Q84 retrospective oracle must not enter the ex-ante strategy set")
    add_error(errors, all(item.get("ex_ante_eligible") is True for item in base_records),
              "Q84 base strategy ex-ante eligibility is not explicit")
    allowed_relationships = {
        "EQUIVALENT", "COMPLEMENTARY_CANDIDATE", "ANTAGONISTIC_A_DOMINATES_B",
        "ANTAGONISTIC_B_DOMINATES_A", "REDUNDANT", "UNRESOLVED",
    }
    add_error(errors, all(item.get("strategy_type") in allowed_relationships for item in pair_records),
              "Q84 pair catalog contains an unknown relationship type")
    add_error(errors, all(item.get("ex_ante_eligible") is False for item in pair_records),
              "Q84 paired relationship records must not be forecasts")

    required_ledger = {
        "target_date", "cutoff_date", "prior_draws", "split", "strategy_id",
        "strategy_type", "rule_sequence", "actual_quintet", "ranking_order_1_to_40",
        "actual_number_ranks", "hits_top5", "hits_top10", "hits_top20",
        "all5_top5", "all5_top10", "all5_top20", "prior_strategy_targets",
        "prior_top20_success_rate_50", "prior_top20_success_rate_200",
        "pre_target_state", "state_detectable_before_target", "evaluation_mode",
    }
    add_error(errors, required_ledger.issubset(set(ledger_fields)),
              "Q84 target ledger schema incomplete")
    add_error(errors, len(ledger_rows) == expected_rows, "Q84 target ledger row count mismatch")

    archive_dates = [row["data"] for row in archive]
    archive_by_date = {
        row["data"]: " ".join(str(int(row["n" + str(i)])) for i in range(1, 6))
        for row in archive
    }
    strategy_by_id = {item.get("strategy_id"): item for item in base_records}
    allowed_states = {"WARMUP", "IMPROVING", "DECLINING", "STABLE", "DORMANT"}
    seen = set()
    if len(ledger_rows) == expected_rows and strategy_count:
        for row_index, row in enumerate(ledger_rows):
            target_index = minimum + row_index // strategy_count
            strategy_position = row_index % strategy_count
            target_date = archive_dates[target_index]
            expected_cutoff = archive_dates[target_index - 1]
            expected_strategy = strategy_ids[strategy_position]
            key = (row.get("target_date"), row.get("strategy_id"))
            if key in seen:
                errors.append("duplicate Q84 strategy/target row " + str(key))
                break
            seen.add(key)
            if row.get("target_date") != target_date or row.get("cutoff_date") != expected_cutoff:
                errors.append("Q84 target/cutoff sequence mismatch at ledger row " + str(row_index))
                break
            if int(row.get("prior_draws", -1)) != target_index:
                errors.append("Q84 prior draw count mismatch at " + target_date)
                break
            if row.get("strategy_id") != expected_strategy:
                errors.append("Q84 strategy ordering/coverage mismatch at " + target_date)
                break
            if row.get("actual_quintet") != archive_by_date[target_date]:
                errors.append("Q84 actual quintet mismatch at " + target_date)
                break
            split_offset = target_index - minimum
            expected_split = (
                "discovery" if split_offset < discovery_end else
                ("validation" if split_offset < validation_end else "blind_oos")
            )
            if row.get("split") != expected_split:
                errors.append("Q84 chronological split mismatch at " + target_date)
                break
            ranking = [int(value) for value in row.get("ranking_order_1_to_40", "").split()]
            if len(ranking) != 40 or set(ranking) != set(range(1, 41)):
                errors.append("Q84 full 1..40 ranking is invalid at " + target_date)
                break
            actual = [int(value) for value in row["actual_quintet"].split()]
            ranks = json.loads(row.get("actual_number_ranks", "[]"))
            rank_map = {number: position + 1 for position, number in enumerate(ranking)}
            expected_ranks = [rank_map[number] for number in actual]
            if ranks != expected_ranks:
                errors.append("Q84 actual winning-number ranks do not reconcile at " + target_date)
                break
            hits = {
                "hits_top5": sum(value <= 5 for value in ranks),
                "hits_top10": sum(value <= 10 for value in ranks),
                "hits_top20": sum(value <= 20 for value in ranks),
            }
            for field, value in hits.items():
                if int(row.get(field, -1)) != value:
                    errors.append("Q84 " + field + " mismatch at " + target_date)
                    break
            if errors:
                break
            for field, cutoff in (("all5_top5", 5), ("all5_top10", 10), ("all5_top20", 20)):
                if int(row.get(field, -1)) != int(all(value <= cutoff for value in ranks)):
                    errors.append("Q84 " + field + " mismatch at " + target_date)
                    break
            if errors:
                break
            prior_count = target_index - minimum
            if int(row.get("prior_strategy_targets", -1)) != prior_count:
                errors.append("Q84 pre-target state history count mismatch at " + target_date)
                break
            detectable = row.get("state_detectable_before_target", "").lower() == "true"
            if detectable != (prior_count >= 50):
                errors.append("Q84 state detectability flag mismatch at " + target_date)
                break
            if row.get("pre_target_state") not in allowed_states:
                errors.append("Q84 unknown pre-target state at " + target_date)
                break
            if row.get("evaluation_mode") != "STRICT_PRIOR_WALK_FORWARD":
                errors.append("Q84 ex-ante/retrospective mode mismatch at " + target_date)
                break
            for field in ("prior_top20_success_rate_50", "prior_top20_success_rate_200",
                          "prior_top20_success_rate_delta_50_200", "prior_mean_top20_hits_50"):
                value = float(row.get(field, "nan"))
                if not math.isfinite(value):
                    errors.append("Q84 non-finite state metric " + field + " at " + target_date)
                    break
            if errors:
                break

    lifecycle_strategies = lifecycle.get("strategy_lifecycle", [])
    lifecycle_pairs = lifecycle.get("pair_relationships", [])
    add_error(errors, lifecycle.get("task_id") == "Q84", "Q84 lifecycle task id mismatch")
    add_error(errors, len(lifecycle_strategies) == strategy_count,
              "Q84 lifecycle strategy count mismatch")
    add_error(errors, len(lifecycle_pairs) == expected_pairs,
              "Q84 lifecycle pair relationship count mismatch")
    mt = lifecycle.get("multiple_testing", {})
    add_error(errors, mt.get("strategy_performance", {}).get("family_size") == strategy_count * 3 * 3 * 2,
              "Q84 strategy multiple-testing family size mismatch")
    add_error(errors, mt.get("pairwise_relationships", {}).get("family_size") == expected_pairs * 2,
              "Q84 paired multiple-testing family size mismatch")

    add_error(errors, len(metric_rows) == strategy_count * 3,
              "Q84 strategy metrics row count mismatch")
    add_error(errors, len(pair_rows) == expected_pairs,
              "Q84 pair metrics row count mismatch")
    required_metric_fields = {
        "strategy_id", "split", "targets", "mean_number_hits_top5",
        "mean_number_hits_top10", "mean_number_hits_top20",
        "mean_rank_of_actual_numbers", "holm_number_top20", "holm_all5_top20",
    }
    add_error(errors, required_metric_fields.issubset(set(metric_fields)),
              "Q84 strategy metric schema incomplete")
    for row in metric_rows:
        if row.get("strategy_id") not in set(strategy_ids) or row.get("split") not in Q80_SPLITS:
            errors.append("Q84 strategy metrics contain an unknown strategy/split")
            break
        for field in ("mean_number_hits_top5", "mean_number_hits_top10", "mean_number_hits_top20",
                      "mean_rank_of_actual_numbers", "holm_number_top20", "holm_all5_top20"):
            value = float(row.get(field, "nan"))
            if not math.isfinite(value) or (
                field == "mean_rank_of_actual_numbers" and not 1 <= value <= 40
            ) or (field != "mean_rank_of_actual_numbers" and not 0 <= value <= 1):
                errors.append("Q84 invalid strategy metric " + field)
                break
        if errors:
            break
    required_pair_fields = {
        "relationship_id", "strategy_a", "strategy_b", "targets",
        "mean_top20_candidate_jaccard", "exact_full_ranking_equivalence_rate",
        "top20_set_equivalence_rate", "a_marginal_unique_top20_hit_rate",
        "b_marginal_unique_top20_hit_rate", "a_only_actual_number_hits_top20",
        "b_only_actual_number_hits_top20", "holm_p_hit_count", "holm_p_all5",
        "relationship",
    }
    add_error(errors, required_pair_fields.issubset(set(pair_fields)),
              "Q84 pair metric schema incomplete")
    for row in pair_rows:
        if row.get("relationship") not in allowed_relationships:
            errors.append("Q84 pair metrics contain an unknown relationship")
            break
        for field in ("mean_top20_candidate_jaccard", "exact_full_ranking_equivalence_rate",
                      "top20_set_equivalence_rate", "a_marginal_unique_top20_hit_rate",
                      "b_marginal_unique_top20_hit_rate", "holm_p_hit_count", "holm_p_all5"):
            value = float(row.get(field, "nan"))
            if not math.isfinite(value) or not 0 <= value <= 1:
                errors.append("Q84 invalid pair metric " + field)
                break
        if errors:
            break

    grammar = report.get("formula_grammar_boundary", {})
    add_error(errors, grammar.get("registered_strategy_count") == strategy_count,
              "Q84 finite grammar count mismatch")
    add_error(errors, "does not exhaust mathematical formulas" in grammar.get("description", ""),
              "Q84 finite grammar boundary disclaimer missing")
    add_error(errors, any("strict-prior" in item.lower() for item in report.get("guardrails", [])),
              "Q84 strict-prior guardrail missing")
    add_error(errors, any("retrospective" in item.lower() for item in report.get("guardrails", [])),
              "Q84 retrospective separation guardrail missing")
    add_error(errors, any("immutable" in item.lower() for item in report.get("guardrails", [])),
              "Q84 immutable freeze guardrail missing")
    return errors


