import importlib.util
from pathlib import Path
import unittest
import numpy as np

P=Path(__file__).resolve().parents[1] / 'scripts' / 'sonar_q141_q90_family_persistence.py'
spec=importlib.util.spec_from_file_location('q141_b7',P)
m=importlib.util.module_from_spec(spec); spec.loader.exec_module(m)

class Q141B7Tests(unittest.TestCase):
    def test_selector_excludes_current_and_future(self):
        rng=np.random.default_rng(141)
        x=rng.random((180,7))
        original=m.select_families(x)
        for t in (100,101,119,150,179):
            y=x.copy(); y[t:]=rng.random(y[t:].shape)
            changed=m.select_families(y)
            self.assertEqual(int(original[t]),int(changed[t]))
        self.assertTrue(np.all(original[:100]==-1))

    def test_formula_scores_match_scalar_definitions(self):
        rng=np.random.default_rng(142)
        X=rng.normal(size=(40,20))
        sample=[
            {'formula_id':'L4','family':'linear_mean_L4','type':'linear_mean','size':4,'local_ids':(0,1,2,3)},
            {'formula_id':'I4','family':'pairwise_interaction_I4','type':'pairwise_interaction','size':4,'local_ids':(0,1,2,3),'pair_local':(0,2),'weight':0.25},
            {'formula_id':'G4','family':'conditional_gate_G4','type':'conditional_gate','size':4,'local_ids':(0,1,2,3),'gate_local':1,'threshold':0.5,'weight':0.25},
        ]
        W,fams,ic,ip,gc,gf,gt,pairs=m.build_formula_arrays(sample,np.arange(20))
        scores=m.score_one_target(X,W,sample,ic,ip,gc,gf,gt,pairs)
        base=np.round(X[:,:4].mean(axis=1),12)
        np.testing.assert_allclose(scores[:,0],base,rtol=0,atol=1e-12)
        prod=X[:,0]*X[:,2]; sd=prod.std() or 1.0
        expected_i=np.round(base+0.25*(prod-prod.mean())/sd,12)
        np.testing.assert_allclose(scores[:,1],expected_i,rtol=0,atol=1e-12)
        expected_g=np.round(base+0.25*(X[:,1]>=0.5),12)
        np.testing.assert_allclose(scores[:,2],expected_g,rtol=0,atol=1e-12)

    def test_rank_ties_resolve_to_lower_number(self):
        scores=np.zeros((40,1)); scores[3,0]=1.0; scores[1,0]=1.0
        # Both tied candidates 2 and 4 rank by ascending number, so number 2 is ahead.
        v=scores[1,:][None,:]
        rank2=1+(scores>v).sum(axis=0)+((scores==v)&(np.arange(40)[:,None]<1)).sum(axis=0)
        v=scores[3,:][None,:]
        rank4=1+(scores>v).sum(axis=0)+((scores==v)&(np.arange(40)[:,None]<3)).sum(axis=0)
        self.assertEqual(int(rank2[0]),1)
        self.assertEqual(int(rank4[0]),2)

if __name__=='__main__': unittest.main(verbosity=2)
